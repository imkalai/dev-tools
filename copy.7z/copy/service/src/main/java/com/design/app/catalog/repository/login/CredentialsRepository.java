package com.design.app.catalog.repository.login;


import com.design.app.catalog.model.login.Credentials;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CredentialsRepository extends JpaRepository<Credentials, Long> {
    List<Credentials> findAll();

    Credentials findById(long id);

    Credentials findByEmailEqualsAndPasswordEquals(String email, String password);

    Credentials findByUsernameEqualsAndPasswordEquals(String userName, String password);
}
