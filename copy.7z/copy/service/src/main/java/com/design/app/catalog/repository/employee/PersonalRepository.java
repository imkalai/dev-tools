package com.design.app.catalog.repository.employee;


import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.employee.Personal;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PersonalRepository extends JpaRepository<Personal, Long> {
    List<Personal> findAll();

    Personal findById(long id);

    Personal findByName(Name name);
}