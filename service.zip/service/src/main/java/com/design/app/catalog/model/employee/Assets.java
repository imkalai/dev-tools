package com.design.app.catalog.model.employee;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.math.BigInteger;

@Entity
@Table(name = "assets")
public class Assets {

    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "name_id")
    private Name name;

    private String cardNumber;
    private String cardAccessNumber;

    public Assets() {
    }

    public long getId() {
        return Id;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardAccessNumber() {
        return cardAccessNumber;
    }

    public void setCardAccessNumber(String cardAccessNumber) {
        this.cardAccessNumber = cardAccessNumber;
    }
}
