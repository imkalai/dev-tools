package com.design.app.catalog.repository.department;

import com.design.app.catalog.model.account.Account;
import com.design.app.catalog.model.department.Department;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    List<Department> findAll();

    Department findById(long id);

    Department findByName(String departmentName);

    Department findByAlias(String alias);
}