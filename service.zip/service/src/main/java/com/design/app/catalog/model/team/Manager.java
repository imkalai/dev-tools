package com.design.app.catalog.model.team;

import com.design.app.catalog.model.account.Account;
import com.design.app.catalog.model.department.Department;
import com.design.app.catalog.model.employee.Name;

import javax.persistence.*;

@Entity
@Table(name = "manager")
public class Manager {
    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @ManyToOne
    @JoinColumn(name = "name_id")
    private Name name;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    public Manager() {
    }

    public long getId() {
        return Id;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}
