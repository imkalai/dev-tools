package com.design.app.catalog.repository.employee;


import com.design.app.catalog.model.employee.Certificates;
import com.design.app.catalog.model.employee.Name;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CertificatesRepository extends JpaRepository<Certificates, Long> {
    List<Certificates> findAll();

    Certificates findById(long id);

    Certificates findByName(Name name);
}