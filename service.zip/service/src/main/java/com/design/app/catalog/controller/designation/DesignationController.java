package com.design.app.catalog.controller.designation;


import com.design.app.catalog.api.designation.DesignationApi;
import com.design.app.catalog.model.designation.Designation;
import com.design.app.catalog.repository.designation.DesignationRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class DesignationController implements DesignationApi {

    @Autowired
    DesignationRepository repository;

    @Override
    public ResponseEntity<List<Designation>> getAllDesignations() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<Designation> createDesignation(Designation designation) {
        return ResponseEntity.ok(repository.saveAndFlush(designation));
    }

    @Override
    public ResponseEntity<List<Designation>> createDesignationBatch(List<Designation> designations) {
        for (Designation designation: designations) {
//            designation.setCreatedDateTime(LocalDateTime.now());
//            designation.setLastModifiedDateTime(LocalDateTime.now());
        }
        return ResponseEntity.ok(repository.saveAll(designations));
    }
    @Override
    public ResponseEntity<Designation> editDesignation(long designation_id, Designation designation) {
        Designation oldDesignation = repository.findById(designation_id);
        BeanUtils.copyProperties(designation,oldDesignation);
        return ResponseEntity.ok(repository.save(oldDesignation));
    }

    @Override
    public ResponseEntity<String> deleteDesignation(long designation_id) {
        repository.delete(repository.findById(designation_id));
        return ResponseEntity.ok("Designation removed successfully");
    }

    @Override
    public ResponseEntity<Designation> getDesignation(long designation_id) {
        return ResponseEntity.ok(repository.findById(designation_id));
    }


}

