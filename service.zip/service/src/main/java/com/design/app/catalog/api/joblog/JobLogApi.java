package com.design.app.catalog.api.joblog;

import com.design.app.catalog.model.joblog.JobLog;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "JobLog API", tags = {"JobLog"}, description = "JobLog API")
@RequestMapping(value = "/app/catalog")
public interface JobLogApi {

    @ApiOperation(value = "Gets all jobLogs",
            notes = "Returns all jobLogs from db",
            response = JobLog.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of jobLogs", response = JobLog.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/jobLog/all",
            method = RequestMethod.GET)
    ResponseEntity<List<JobLog>> getAllJobLog();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new JobLog",
            notes = "Creates a new jobLog",
            response = JobLog.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "JobLog Details", response = JobLog.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/jobLog/add",
            method = RequestMethod.POST)
    ResponseEntity<?> createJobLog(@ApiParam(value = "", required = true) @RequestBody JobLog jobLog);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of JobLogs",
            notes = "Creates a set of JobLogs",
            response = JobLog.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "JobLog Details", response = JobLog.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/jobLog/add/batch",
            method = RequestMethod.POST)
    ResponseEntity<?> createJobLogBatch(@ApiParam(value = "", required = true) @RequestBody List<JobLog> jobLogs);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing JobLog",
            notes = "Edit an existing jobLog",
            response = JobLog.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "JobLog Details", response = JobLog.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/jobLog/{id}",
            method = RequestMethod.PUT)
    ResponseEntity<?> editJobLog(@ApiParam(value = "", required = true) @PathVariable("id") long jobLog_id,
                                 @ApiParam(value = "", required = true) @RequestBody JobLog jobLog);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing JobLog",
            notes = "Delete an existing jobLog",
            response = JobLog.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "JobLog Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/jobLog/{id}",
            method = RequestMethod.DELETE)
    ResponseEntity<String> deleteJobLog(@ApiParam(value = "", required = true) @PathVariable("id") long jobLog_id);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing JobLog",
            notes = "Gets an existing jobLog",
            response = JobLog.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "JobLog Details", response = JobLog.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/jobLog/{id}",
            method = RequestMethod.GET)
    ResponseEntity<?> getJobLog(@ApiParam(value = "", required = true) @PathVariable("id") long jobLog_id);

    /////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing JobLog",
            notes = "Gets an existing jobLog",
            response = JobLog.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "JobLog Details", response = JobLog.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/jobLog/structure/{id}",
            method = RequestMethod.GET)
    ResponseEntity<?> getAccountStructure(@ApiParam(value = "", required = true) @PathVariable("id") long name_id);

    /////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing JobLog",
            notes = "Gets an existing jobLog",
            response = JobLog.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "JobLog Details", response = JobLog.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/jobLog/employee/{empcode}/{status}",
            method = RequestMethod.GET)
    ResponseEntity<?> getJobLogByEmployee(@ApiParam(value = "", required = true) @PathVariable("empcode") String empCode,
                                          @ApiParam(value = "", required = true) @PathVariable("status") String status);
    /////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing JobLog",
            notes = "Gets an existing jobLog",
            response = JobLog.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "JobLog Details", response = JobLog.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/jobLog/employee/{empcode}/{year}/{month}/{status}",
            method = RequestMethod.GET)
    ResponseEntity<?> getJobLogByEmployeeByPeriod(@ApiParam(value = "", required = true) @PathVariable("empcode") String empCode,
                                                  @ApiParam(value = "", required = true) @PathVariable("year") String year,
                                                  @ApiParam(value = "", required = true) @PathVariable("month") String month,
                                                  @ApiParam(value = "", required = true) @PathVariable("status") String status);

}

