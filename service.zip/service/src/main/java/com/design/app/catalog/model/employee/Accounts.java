package com.design.app.catalog.model.employee;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.math.BigInteger;

@Entity
@Table(name = "accounts")
public class Accounts {
    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "name_id")
    private Name name;

    private String bankName;
    private String accountNumber;
    private String ifscCode;
    private String branch;
    private String salaryAccountNumber;
    private String salaryIFSCCode;
    private String salaryBranch;

    public Accounts() {
    }

    public long getId() {
        return Id;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getSalaryAccountNumber() {
        return salaryAccountNumber;
    }

    public void setSalaryAccountNumber(String salaryAccountNumber) {
        this.salaryAccountNumber = salaryAccountNumber;
    }

    public String getSalaryIFSCCode() {
        return salaryIFSCCode;
    }

    public void setSalaryIFSCCode(String salaryIFSCCode) {
        this.salaryIFSCCode = salaryIFSCCode;
    }

    public String getSalaryBranch() {
        return salaryBranch;
    }

    public void setSalaryBranch(String salaryBranch) {
        this.salaryBranch = salaryBranch;
    }
}
