package com.design.app.catalog.model.payroll;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

@Entity
@Table(name = "employmentterms")
public class EmploymentTerms {
    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    private String empCode;
    private double monthly;
    private double annual;
    private String category;
    private double fixedBasic;
    private double fixedDa;
    private double fixedHra;

    public EmploymentTerms() {
    }

    public long getId() {
        return Id;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public double getAnnual() {
        return annual;
    }

    public void setAnnual(double annual) {
        this.annual = annual;
    }

    public double getMonthly() {
        return monthly;
    }

    public void setMonthly(double monthly) {
        this.monthly = monthly;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getFixedBasic() {
        return fixedBasic;
    }

    public void setFixedBasic(double fixedBasic) {
        this.fixedBasic = fixedBasic;
    }

    public double getFixedDa() {
        return fixedDa;
    }

    public void setFixedDa(double fixedDa) {
        this.fixedDa = fixedDa;
    }

    public double getFixedHra() {
        return fixedHra;
    }

    public void setFixedHra(double fixedHra) {
        this.fixedHra = fixedHra;
    }
}
