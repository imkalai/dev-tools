package com.design.app.catalog.repository.payroll;

import com.design.app.catalog.model.payroll.EmploymentTerms;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmploymentTermsRepository extends JpaRepository<EmploymentTerms, Long> {
    List<EmploymentTerms> findAll();

    EmploymentTerms findById(long id);

    EmploymentTerms findByEmpCode(String empCode);
}