package com.design.app.catalog.api.payroll;


import com.design.app.catalog.model.payroll.PayrollCategory;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "PayrollCategory API", tags = {"PayrollCategory"}, description = "PayrollCategory API")
@RequestMapping(value = "/app/catalog")
public interface PayrollCategoryApi {

    @ApiOperation(value = "Gets all payrollcategorys",
            notes = "Returns all payrollcategorys from db",
            response = PayrollCategory.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of payrollcategorys", response = PayrollCategory.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/payrollcategory/all",
            method= RequestMethod.GET)
    ResponseEntity<List<PayrollCategory>> getAllPayrollCategory();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new PayrollCategory",
            notes = "Creates a new payrollcategory",
            response = PayrollCategory.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "PayrollCategory Details", response = PayrollCategory.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/payrollcategory/add",
            method= RequestMethod.POST)
    ResponseEntity<?> createPayrollCategory(@ApiParam(value = "",required = true) @RequestBody PayrollCategory payrollcategory);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Edit an existing PayrollCategory",
            notes = "Edit an existing payrollcategory",
            response = PayrollCategory.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "PayrollCategory Details", response = PayrollCategory.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/payrollcategory/{id}",
            method= RequestMethod.PUT)
    ResponseEntity<?> editPayrollCategory(@ApiParam(value = "",required = true) @PathVariable("id") long payrollcategory_id,
                                          @ApiParam(value = "",required = true) @RequestBody PayrollCategory payrollcategory);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing PayrollCategory",
            notes = "Delete an existing payrollcategory",
            response = PayrollCategory.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "PayrollCategory Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/payrollcategory/{id}",
            method= RequestMethod.DELETE)
    ResponseEntity<String> deletePayrollCategory(@ApiParam(value = "",required = true) @PathVariable("id") long payrollcategory_id  );

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing PayrollCategory",
            notes = "Gets an existing payrollcategory",
            response = PayrollCategory.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "PayrollCategory Details", response = PayrollCategory.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/payrollcategory/{name}",
            method= RequestMethod.GET)
    ResponseEntity<?> getPayrollCategory(@ApiParam(value = "",required = true) @PathVariable("name") String payrollcategory);

}

