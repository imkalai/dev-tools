package com.design.app.catalog.controller.file;

import com.design.app.catalog.controller.employee.EmployeeController;
import com.design.app.catalog.helpers.FileStorageService;
import com.design.app.catalog.model.attendance.Attendance;
import com.design.app.catalog.model.department.Department;
import com.design.app.catalog.model.designation.Designation;
import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.employee.*;
import com.design.app.catalog.model.files.DataFile;
import com.design.app.catalog.model.files.ResponseFile;
import com.design.app.catalog.model.files.ResponseMessage;
import com.design.app.catalog.repository.attendance.AttendanceRepository;
import com.design.app.catalog.repository.employee.EmployeeRepository;
import com.design.app.catalog.repository.files.FileDBRepository;
import com.google.gson.Gson;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;


@Controller
@Transactional
//@CrossOrigin("http://localhost:8081")
public class FileController {

    @Autowired
    private FileStorageService storageService;

    @Autowired
    AttendanceRepository attendanceRepository;

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    FileDBRepository fileDBRepository;

    @Autowired
    EmployeeController employeeController;

    @PostMapping("/app/catalog/attendance/upload")
    public ResponseEntity<ResponseMessage> AttendanceuploadFile(@RequestParam("file") MultipartFile file) {
        String message = "";
        try {
            DataFile dataFile = fileDBRepository.findByNameAndType(file.getOriginalFilename(), file.getContentType());
            if (dataFile != null)
                return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage("Duplicate File. File already processed"));
            else {
                storageService.store(file);
                List<Attendance> attendances = processAttendance("C:\\uploads\\" + file.getOriginalFilename());
                attendanceRepository.saveAll(attendances);
                //<To DO: verify employee before saving>
                message = "Uploaded the file successfully: " + file.getOriginalFilename();
                return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));
            }
        } catch (Exception e) {
            message = "Could not upload the file: " + file.getOriginalFilename() + "!";
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
        }
    }

    private List<Attendance> processAttendance(String filename) {
        List<Attendance> data = new ArrayList<Attendance>();
        try {
            Workbook workbook = WorkbookFactory.create(new File(filename));

            for (int i = 1; i < 3; i++) {
                Sheet datatypeSheet = workbook.getSheetAt(i);
                Iterator<Row> iterator = datatypeSheet.iterator();
                Gson gson = new Gson();
                int rowNum = 0;
                boolean nextDate = false;
                LocalDate currentDate = null;

                while (iterator.hasNext()) {
                    rowNum++;
                    Row currentRow = iterator.next();
                    if (rowNum > 5) {
                        Iterator<Cell> cellIterator = currentRow.iterator();
                        Attendance attendance = new Attendance();
                        if (currentDate != null)
                            attendance.setDate(currentDate);

                        while (cellIterator.hasNext()) {

                            Cell currentCell = cellIterator.next();

                            if (currentCell.getCellType() == CellType.STRING) {

                                if (currentCell.getStringCellValue().equalsIgnoreCase("department") || currentCell.getStringCellValue().equalsIgnoreCase("sno")) {
                                    break;
                                } else if (currentCell.getStringCellValue().equalsIgnoreCase("attendance date")) {
                                    nextDate = true;
                                } else {
                                    if (nextDate) {
                                        currentDate = getAttendanceDate(currentCell.getStringCellValue());
                                        nextDate = false;
                                    } else {

                                        switch (currentCell.getColumnIndex()) {
                                            case 2:
                                                attendance.setEmpCode(currentCell.getStringCellValue());
                                                break;
                                            case 3:
                                                attendance.setName(currentCell.getStringCellValue());
                                                break;
                                            case 5:
                                                attendance.setShift(currentCell.getStringCellValue());
                                                break;
                                            case 7:
                                                attendance.setInTime(getParsedAttendanceTime(currentCell.getStringCellValue()));
                                                break;
                                            case 8:
                                                attendance.setOutTime(getParsedAttendanceTime(currentCell.getStringCellValue()));
                                                break;
                                            case 10:
                                                attendance.setWorkDuration(getParsedAttendanceTime(currentCell.getStringCellValue()));
                                                break;
                                            case 11:
                                                attendance.setOvertime(getParsedAttendanceTime(currentCell.getStringCellValue()));
                                                break;
                                            case 12:
                                                attendance.setTotal(getParsedAttendanceTime(currentCell.getStringCellValue()));
                                                break;
                                            case 13:
                                                attendance.setStatus(currentCell.getStringCellValue());
                                                break;
//                                        case 11:
//                                            attendance.setRemarks(currentCell.getStringCellValue());
//                                            break;
                                            default:
                                                break;
                                        }

//                                    System.out.print(currentCell.getStringCellValue() + "--");
                                    }
                                }
                            } else if (currentCell.getCellType() == CellType.NUMERIC) {
//                            System.out.print("'N'"+currentCell.getNumericCellValue() + "--");
                            }

                        }
                        if (attendance.getEmpCode() != null) {
//                            System.out.print(gson.toJson(attendance));
                            data.add(attendance);
//                            System.out.println();
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }

    @GetMapping("/app/catalog/files")
    public ResponseEntity<List<ResponseFile>> getListFiles() {
        List<ResponseFile> files = storageService.getAllFiles().map(dbDataFile -> {
            String fileDownloadUri = ServletUriComponentsBuilder
                    .fromCurrentContextPath()
                    .path("/app/catalog/files/")
                    .path(dbDataFile.getId())
                    .toUriString();

            return new ResponseFile(
                    dbDataFile.getName(),
                    fileDownloadUri,
                    dbDataFile.getType(),
                    dbDataFile.getData().length);
        }).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(files);
    }

    @GetMapping("/app/catalog/files/{id}")
    public ResponseEntity<byte[]> getFile(@PathVariable String id) {
        DataFile dataFile = storageService.getFile(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + dataFile.getName() + "\"")
                .body(dataFile.getData());
    }

    @PostMapping("/app/catalog/employee/upload")
    public ResponseEntity<ResponseMessage> AttendanceEmployeeFile(@RequestParam("file") MultipartFile file) {
        String message = "";
        try {
            DataFile dataFile = fileDBRepository.findByNameAndType(file.getOriginalFilename(), file.getContentType());
            if (dataFile != null)
                return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage("Duplicate File. File already processed"));
            else {
                storageService.store(file);
                List<Employee> employees = processEmployee("C:\\uploads\\" + file.getOriginalFilename());
                ResponseEntity<?> responseEntity = employeeController.createEmployeeBatch(employees);
                if (responseEntity.getStatusCode() == HttpStatus.OK) {
                    message = "Uploaded the file successfully: " + file.getOriginalFilename();
                    return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));

                } else
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseMessage("Failed to onboard employee(s)"));
//                    return ResponseEntity.status(HttpStatus.OK).body(new ResponseMessage(message));

            }
        } catch (Exception e) {
            e.printStackTrace();
            message = "Could not upload the file: " + file.getOriginalFilename() + "!";
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(new ResponseMessage(message));
        }
    }

    private List<Employee> processEmployee(String filename) {
        List<Employee> data = new ArrayList<Employee>();
        try {
            Workbook workbook = WorkbookFactory.create(new File(filename));

            for (int i = 0; i < 1; i++) {
                Sheet datatypeSheet = workbook.getSheetAt(i);
                Iterator<Row> iterator = datatypeSheet.iterator();
                Gson gson = new Gson();
                int rowNum = 0;

                while (iterator.hasNext()) {
                    rowNum++;
                    Row currentRow = iterator.next();
                    if (rowNum > 1) {
                        Iterator<Cell> cellIterator = currentRow.iterator();
                        Employee employee = new Employee();
                        Name name = new Name();
                        Personal personalDetails = new Personal();
                        Employment employmentDetails = new Employment();
                        Accounts accountDetails = new Accounts();
                        Statuatory statuatoryDetails = new Statuatory();
                        Education educationDetails = new Education();
                        Family familyDetails = new Family();
                        Assets assetDetails = new Assets();
                        Certificates certificateDetails = new Certificates();

                        while (cellIterator.hasNext()) {

                            Cell currentCell = cellIterator.next();

//                            System.out.println("CurrentCell Type: " + currentCell.getCellType() + " - index: " + currentCell.getColumnIndex());
                            if (currentCell.getCellType() == CellType.STRING) {

                                if (currentCell.getStringCellValue().equalsIgnoreCase("department") || currentCell.getStringCellValue().equalsIgnoreCase("sno")) {
                                    break;
                                } else {
                                    switch (currentCell.getColumnIndex()) {
                                        case 1:
                                            name.setEmployeeCode(parseEmployeeCode(currentCell.getStringCellValue()));
                                            employmentDetails.setEmployeeID(currentCell.getStringCellValue());
                                            employmentDetails.setEmployeeCode(parseEmployeeCode(currentCell.getStringCellValue()));
                                            break;
                                        case 2:
                                            name.setFirstName(currentCell.getStringCellValue());
                                            break;


                                        case 7:
                                            personalDetails.setGender(currentCell.getStringCellValue());
                                            break;
                                        case 8:
                                            Designation designation = new Designation();
                                            designation.setName(currentCell.getStringCellValue());
                                            employmentDetails.setDesignation(designation);
                                            break;
                                        case 9:
                                            employmentDetails.setDepartment(new Department(currentCell.getStringCellValue()));
                                            break;
                                        case 11:
                                            statuatoryDetails.setPfNumber(currentCell.getStringCellValue());
                                            break;

                                        case 13:
                                            statuatoryDetails.setEsiNumber(currentCell.getStringCellValue());
                                            break;
                                        case 14:
                                            assetDetails.setCardNumber(currentCell.getStringCellValue());
                                            break;
                                        case 16:
                                            personalDetails.setCurrentAddress(currentCell.getStringCellValue());
                                            break;
                                        case 17:
                                            personalDetails.setPermanentAddress(currentCell.getStringCellValue());
                                            break;

                                        case 19:
                                            personalDetails.setEmail(currentCell.getStringCellValue());
                                            break;
                                        case 20:
                                            personalDetails.setMaritalStatus(currentCell.getStringCellValue());
                                            break;
                                        case 21:
                                            statuatoryDetails.setAadhar(currentCell.getStringCellValue());
                                            break;

                                        case 23:
                                            statuatoryDetails.setAadharName(currentCell.getStringCellValue());
                                            break;
                                        case 24:
                                            statuatoryDetails.setPan(currentCell.getStringCellValue());
                                            break;
                                        case 25:
                                            statuatoryDetails.setPanName(currentCell.getStringCellValue());
                                            break;

                                        case 27:
                                            accountDetails.setBranch(currentCell.getStringCellValue());
                                            break;
                                        case 28:
                                            accountDetails.setIfscCode(currentCell.getStringCellValue());
                                            break;
                                        case 29:
                                            accountDetails.setBankName(currentCell.getStringCellValue());
                                            break;

                                        case 31:
                                            accountDetails.setSalaryIFSCCode(currentCell.getStringCellValue());
                                            break;
                                        case 32:
                                            accountDetails.setSalaryBranch(currentCell.getStringCellValue());
                                            break;
                                        case 33:
                                            certificateDetails.setCertificateName(currentCell.getStringCellValue());
                                            break;
                                        case 34:
                                            certificateDetails.setCertificateNumber(currentCell.getStringCellValue());
                                            break;
                                        case 35:
                                            familyDetails.setFatherName(currentCell.getStringCellValue());
                                            break;
                                        case 36:
                                            familyDetails.setFatherAadhar(currentCell.getStringCellValue());
                                            break;
                                        case 37:
                                            familyDetails.setFatherDob(getProcessedDate(currentCell.getStringCellValue()));
                                            break;

                                        case 39:
                                            familyDetails.setMotherName(currentCell.getStringCellValue());
                                            break;
                                        case 40:
                                            familyDetails.setMotherAadhar(currentCell.getStringCellValue());
                                            break;
                                        case 41:
                                            familyDetails.setMotherDob(getProcessedDate(currentCell.getStringCellValue()));
                                            break;

                                        case 43:
                                            familyDetails.setSpouseName(currentCell.getStringCellValue());
                                            break;
                                        case 44:
                                            familyDetails.setSpouseAadhar(currentCell.getStringCellValue());
                                            break;
                                        case 45:
                                            familyDetails.setSpouseDob(getProcessedDate(currentCell.getStringCellValue()));
                                            break;
                                        case 46:
                                            familyDetails.setKid1Name(currentCell.getStringCellValue());
                                            break;
                                        case 47:
                                            familyDetails.setKid1Aadhar(currentCell.getStringCellValue());
                                            break;
                                        case 48:
                                            familyDetails.setKid1Dob(getProcessedDate(currentCell.getStringCellValue()));
                                            break;
                                        case 49:
                                            familyDetails.setKid2Name(currentCell.getStringCellValue());
                                            break;
                                        case 50:
                                            familyDetails.setKid2Aadhar(currentCell.getStringCellValue());
                                            break;
                                        case 51:
                                            familyDetails.setKid2Dob(getProcessedDate(currentCell.getStringCellValue()));
                                            break;
                                        case 52:
                                            familyDetails.setEmergencyContact(currentCell.getStringCellValue());
                                            break;
                                        case 53:
                                            familyDetails.setEmergencyNumber(currentCell.getStringCellValue());
                                            break;
                                        case 54:
                                            personalDetails.setBloodGroup(currentCell.getStringCellValue());
                                            break;

                                        case 56:
                                            personalDetails.setReligion(currentCell.getStringCellValue());
                                            break;
                                        case 57:
                                            educationDetails.setDegree(currentCell.getStringCellValue());
                                            break;
                                        case 59:
                                            educationDetails.setCompleted(currentCell.getStringCellValue());
                                            break;
                                        case 60:
                                            educationDetails.setInstitution(currentCell.getStringCellValue());
                                            break;
                                        case 63:
                                            break;
                                        case 64:
                                            break;

                                        case 3:
                                            personalDetails.setDateOfBirth(getProcessedDate(currentCell.getStringCellValue()));
                                            break;
                                        case 4:
                                            employmentDetails.setDateOfJoining(getProcessedDate(currentCell.getStringCellValue()));
                                            employmentDetails.setStatus("Active");
                                            break;
                                        case 10:
                                            statuatoryDetails.setUan(String.valueOf(currentCell.getNumericCellValue()));
                                            break;
                                        case 12:
                                            statuatoryDetails.setPfJoiningDate(getProcessedDate(currentCell.getStringCellValue()));
                                            break;


                                        case 15:
                                            assetDetails.setCardAccessNumber(currentCell.getStringCellValue());
                                            break;
                                        case 18:
                                            personalDetails.setPhone(currentCell.getStringCellValue());
                                            break;
                                        case 26:
                                            accountDetails.setAccountNumber(currentCell.getStringCellValue());
                                            break;
                                        case 30:
                                            accountDetails.setSalaryAccountNumber(currentCell.getStringCellValue());
                                            break;

                                        default:
                                            break;
                                    }
                                }
                            } else if (currentCell.getCellType() == CellType.NUMERIC) {
                                switch (currentCell.getColumnIndex()) {
                                    case 3:
                                        personalDetails.setDateOfBirth(getProcessedDate(String.valueOf(currentCell.getDateCellValue())));
                                        break;
                                    case 4:
                                        employmentDetails.setDateOfJoining(getProcessedDate(String.valueOf(currentCell.getDateCellValue())));
                                        break;
                                    case 10:
                                        statuatoryDetails.setUan(((XSSFCell) currentCell).getRawValue());
                                        break;
                                    case 12:
                                        statuatoryDetails.setPfJoiningDate(getProcessedDate(String.valueOf(currentCell.getDateCellValue())));
                                        break;


                                    case 15:
                                        assetDetails.setCardAccessNumber(((XSSFCell) currentCell).getRawValue());
                                        break;
                                    case 18:
                                        personalDetails.setPhone(((XSSFCell) currentCell).getRawValue());
                                        break;
                                    case 26:
                                        accountDetails.setAccountNumber(((XSSFCell) currentCell).getRawValue());
                                        break;
                                    case 30:
                                        accountDetails.setSalaryAccountNumber(((XSSFCell) currentCell).getRawValue());
                                        break;
                                    case 53:
                                        familyDetails.setEmergencyNumber(((XSSFCell) currentCell).getRawValue());
                                        break;
                                }
                            } else {
//                                switch (currentCell.getColumnIndex()) {
//                                    case 53:
//                                        familyDetails.setEmergencyNumber(((XSSFCell) currentCell).getRawValue());
//                                        break;
//                                }
                            }

                        }
                        if (name.getEmployeeCode() != null) {
                            employee.setName(name);
                            employee.setPersonalDetails(personalDetails);
                            employee.setAccountDetails(accountDetails);
                            employee.setEducationDetails(educationDetails);
                            employee.setStatuatoryDetails(statuatoryDetails);
                            employee.setAssetDetails(assetDetails);
                            employee.setCertificateDetails(certificateDetails);
                            employee.setEmploymentDetails(employmentDetails);
                            employee.setFamilyDetails(familyDetails);
                            System.out.print(gson.toJson(employee));
                            data.add(employee);
//                            System.out.println();
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }

    DateFormat dateTimeFormatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");

    LocalDate getProcessedDate(String date) {
        try {
            DateTimeFormatter f = DateTimeFormatter.ofPattern("E MMM dd HH:mm:ss z uuuu")
                    .withLocale(Locale.US);
            ZonedDateTime zdt = ZonedDateTime.parse(date, f);
            return zdt.toLocalDate();
        } catch (Exception ex) {
            return null;
        }
    }


    LocalDate getAttendanceDate(String date) {
        try {
            DateTimeFormatter f = DateTimeFormatter.ofPattern("dd-MMM-yyyy") //01-Dec-2022
                    .withLocale(Locale.US);
            LocalDate zdt = LocalDate.parse(date, f);
            return zdt;
        } catch (Exception ex) {
            return null;
        }
    }

    LocalTime getParsedAttendanceTime(String value) {
        try {
            return LocalTime.parse(value, DateTimeFormatter.ISO_LOCAL_TIME);
        } catch (Exception ex) {
            return null;
        }
    }

    private String parseEmployeeCode(String code) {
        try {
            return code.split("/")[1];

        } catch (Exception ex) {
            return null;
        }
    }
}