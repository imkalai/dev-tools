package com.design.app.catalog.api.employee;


import com.design.app.catalog.model.employee.Employee;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "Employee API", tags = {"Employee"}, description = "Employee API")
@RequestMapping(value = "/app/catalog")
public interface EmployeeApi {

    @ApiOperation(value = "Gets all Employees",
            notes = "Returns all Employees from db",
            response = Employee.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of Categories", response = Employee.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/employee/all",
            method= RequestMethod.GET)
    ResponseEntity<List<Employee>> getAllEmployees();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Gets all Employees",
            notes = "Returns all Employees from db",
            response = Employee.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of Categories", response = Employee.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/employee/{id}",
            method= RequestMethod.GET)
    ResponseEntity<?> getEmployee(@ApiParam(value = "", required = true) @PathVariable("id") long employee_id);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new Employee",
            notes = "Creates a new Employee",
            response = Employee.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Employee Details", response = Employee.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/employee/add",
            method= RequestMethod.POST)
    ResponseEntity<?> createEmployee(@ApiParam(value = "", required = true) @RequestBody Employee employee);
/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of employees",
            notes = "Creates a set of employees",
            response = Employee.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Employee Details", response = Employee.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/employee/add/batch",
            method= RequestMethod.POST)
    ResponseEntity<?> createEmployeeBatch(@ApiParam(value = "", required = true) @RequestBody List<Employee> employees);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing Employee",
            notes = "Edit an existing Employee",
            response = Employee.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Employee Details", response = Employee.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/employee/{id}",
            method= RequestMethod.PUT)
    ResponseEntity<?> editEmployee(@ApiParam(value = "", required = true) @PathVariable("id") long employee_id,
                                          @ApiParam(value = "", required = true) @RequestBody Employee employee);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing Employee",
            notes = "Delete an existing Employee",
            response = Employee.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Employee Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/employee/{id}",
            method= RequestMethod.DELETE)
    ResponseEntity<String> deleteEmployee(@ApiParam(value = "", required = true) @PathVariable("id") long employee_id);

    /////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Gets Employee from Email",
            notes = "Returns Employee from db",
            response = Employee.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of Categories", response = Employee.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/employee/email/{email}",
            method= RequestMethod.GET)
    ResponseEntity<?> getEmployeeByEmail(@ApiParam(value = "", required = true) @PathVariable("email") String email);
}
