package com.design.app.catalog.controller.payroll;

import com.design.app.catalog.model.attendance.Attendance;
import com.design.app.catalog.model.files.ResponseMessage;
import com.design.app.catalog.model.payroll.EmploymentTerms;
import com.design.app.catalog.model.payroll.Salary;
import com.design.app.catalog.repository.attendance.AttendanceRepository;
import com.design.app.catalog.repository.payroll.EmploymentTermsRepository;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.time.LocalDate;
import java.util.List;

@Controller
public class SalaryController {

    @Autowired
    EmploymentTermsController employmentTermsController;

    @Autowired
    EmploymentTermsRepository employmentTermsRepository;

    @Autowired
    AttendanceRepository attendanceRepository;

    @PostMapping("/app/catalog/salary/generate/{empcode}")
    public ResponseEntity<?> generateSalary(@ApiParam(value = "", required = true) @PathVariable("empcode") String empCode) {
        try {
            String remCode = empCode.replaceFirst("^0+(?!$)", "");
            List<Attendance> attendances = attendanceRepository.getAttendances(remCode, LocalDate.parse("2022-12-16"), LocalDate.parse("2023-01-15"));
            EmploymentTerms terms = employmentTermsRepository.findByEmpCode(empCode);

            long presentDays = attendances.stream().filter(attendance -> attendance.getStatus().equalsIgnoreCase("present")).count();
            long absences = attendances.size() - presentDays;

            double earnedBasic = (terms.getFixedBasic() / 31) * attendances.size();
            double earnedDA = (terms.getFixedDa() / 31) * attendances.size();
            double earnedHRA = (terms.getFixedHra() / 31) * attendances.size();
            double basic_da = earnedBasic + earnedDA;
            double gross = earnedHRA + basic_da;
            double travelAllowance = 0;
            double other = 0;
            double totalPay = Math.round(travelAllowance + earnedHRA + other + basic_da);
            double pf12 = Math.round(Math.min(15000 * 0.12, (basic_da + other) * 0.12));
            double pf367 = Math.round(Math.min(15000 * 0.0367, (basic_da + other) * 0.0367));
            double pf833 = Math.round(Math.min(15000 * 0.0833, (basic_da + other) * 0.0833));
            double esi075 = Math.round(terms.getMonthly() > 21000 ? 0 : gross * 0.0075);
            double esi325 = Math.round(terms.getMonthly() > 21000 ? 0 : gross * 0.0325);
            double profTax = Math.round((totalPay > 5001 && totalPay <= 7500) ? 52.5 : ((totalPay > 7501 && totalPay <= 10000) ? 115 : ((totalPay > 10001 && totalPay <= 12500) ? 171 : (totalPay > 12501 && totalPay <= 4000001) ? 208 : 0)));
            double totalDeduction = Math.round(pf12 + esi075 + profTax);
            double finalPay = Math.round(totalPay - totalDeduction);


            Salary salary = new Salary();
            salary.setBasic(earnedBasic);
            salary.setDa(earnedDA);
            salary.setHra(earnedHRA);
            salary.setEarnings(earnedBasic + earnedDA + earnedHRA);
            salary.setPf(pf12);
            salary.setEsi(esi075);
            salary.setProfTax(profTax);
            salary.setOtherDeduction(0);
            salary.setDeductions(totalDeduction);
            salary.setNetPay(finalPay);
            salary.setPf_367(pf367);
            salary.setPf_833(pf833);
            salary.setEsi_325(esi325);

            return ResponseEntity.ok(salary);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(new ResponseMessage(e.getMessage()));
        }
    }
}
