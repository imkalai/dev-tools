package com.design.app.catalog.controller.attendance;

import com.design.app.catalog.repository.attendance.AttendanceRepository;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDate;

@Controller
public class AttendanceController {

    @Autowired
    AttendanceRepository attendanceRepository;

    @GetMapping("/app/catalog/attendance/{empcode}/{year}/{month}")
    public ResponseEntity<?> getAttendance(@ApiParam(value = "", required = true) @PathVariable("empcode") String empCode, @ApiParam(value = "", required = true) @PathVariable("year") String year, @ApiParam(value = "", required = true) @PathVariable("month") String month) {
        try {
            String remCode = empCode.replaceFirst("^0+(?!$)", "");
            return ResponseEntity.ok(attendanceRepository.getAttendances(remCode,
                    LocalDate.parse("2022-12-16"), LocalDate.parse("2023-01-15")));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
