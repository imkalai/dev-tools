package com.design.app.catalog.controller.team;

import com.design.app.catalog.api.team.TeamApi;
import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.team.Manager;
import com.design.app.catalog.model.team.Team;
import com.design.app.catalog.repository.employee.NameRepository;
import com.design.app.catalog.repository.team.ManagerRepository;
import com.design.app.catalog.repository.team.TeamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class TeamController implements TeamApi {

    @Autowired
    TeamRepository repository;

    @Autowired
    NameRepository nameRepository;

    @Autowired
    ManagerRepository managerRepository;

    @Override
    public ResponseEntity<List<Team>> getAllTeam() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<?> createTeam(Team team) {
        try {
            if (validateTeam(team)) {
                Name name = nameRepository.findByEmployeeCode(team.getName().getEmployeeCode());
                if (name != null) {
                    Name mName = nameRepository.findByEmployeeCode(team.getManager().getName().getEmployeeCode());
                    if(mName !=null) {
                        Manager manager = managerRepository.findByName(mName);
                        if (manager != null) {
                            team.setName(name);
                            team.setManager(manager);
                            return ResponseEntity.ok(repository.saveAndFlush(team));
                        }
                    }
                }
            }
            return ResponseEntity.badRequest().body("Validation Failed.");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> createTeamBatch(List<Team> teams) {
        List<Team> successTeams = new ArrayList<>();
        List<Team> failedTeams = new ArrayList<>();
        try {
            for (Team team : teams) {
                if (validateTeam(team)) {
                    Name name = nameRepository.findByEmployeeCode(team.getName().getEmployeeCode());
                    if (name != null) {
                        Name mName = nameRepository.findByEmployeeCode(team.getManager().getName().getEmployeeCode());
                        if(mName!=null) {
                            Manager manager = managerRepository.findByName(mName);
                            if (manager != null) {
                                team.setName(name);
                                team.setManager(manager);
                                successTeams.add(repository.saveAndFlush(team));
                            }
                        }
                    }
                } else
                    failedTeams.add(team);
            }
            return ResponseEntity.ok("Successful Entries:\n" + successTeams + "\n\n" + " Failed Entries:\n" + failedTeams);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> editTeam(long team_id, Team team) {
        try {
            Team oldTeam = repository.findById(team_id);

            Name name = nameRepository.findByEmployeeCode(team.getName().getEmployeeCode());
            if (name != null) {
                oldTeam.setName(name);
                Manager manager = managerRepository.findByName(team.getName());
                if (manager != null) {
                    oldTeam.setManager(manager);
                    return ResponseEntity.ok(repository.save(oldTeam));
                }
            }
            return ResponseEntity.badRequest().body("Bad Request. Validation Failed");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> deleteTeam(long team_id) {
        try {
            repository.delete(repository.findById(team_id));
            return ResponseEntity.ok("Team removed successfully");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getTeam(long team_id) {
        try {
            Team team = repository.findById(team_id);
            if (team != null)
                return ResponseEntity.ok(team);
            else
                return ResponseEntity.badRequest().body("Team not exists.");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    private boolean validateTeam(Team team) {
        try {
            Name name = nameRepository.findByEmployeeCode(team.getName().getEmployeeCode());
            if (name != null) {
                Name mName = nameRepository.findByEmployeeCode(team.getManager().getName().getEmployeeCode());
                if(mName!=null) {
                    Manager manager = managerRepository.findByName(mName);
                    if (manager != null) {
                        return true;
                    }
                }
            }
        } catch (Exception ex) {
            return false;
        }
        return false;
    }
}
