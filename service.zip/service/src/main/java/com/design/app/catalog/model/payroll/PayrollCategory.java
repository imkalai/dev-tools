package com.design.app.catalog.model.payroll;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

@Entity
@Table(name = "payrollcategory")
public class PayrollCategory {
    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    private String category;

    private double startRange;

    private double endRange;

    private double basicPercentile;

    private double daPercentile;

    private double hraPercentile;


    public PayrollCategory() {
    }

    public long getId() {
        return Id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getStartRange() {
        return startRange;
    }

    public void setStartRange(double startRange) {
        this.startRange = startRange;
    }

    public double getEndRange() {
        return endRange;
    }

    public void setEndRange(double endRange) {
        this.endRange = endRange;
    }

    public double getBasicPercentile() {
        return basicPercentile;
    }

    public void setBasicPercentile(double basicPercentile) {
        this.basicPercentile = basicPercentile;
    }

    public double getDaPercentile() {
        return daPercentile;
    }

    public void setDaPercentile(double daPercentile) {
        this.daPercentile = daPercentile;
    }

    public double getHraPercentile() {
        return hraPercentile;
    }

    public void setHraPercentile(double hraPercentile) {
        this.hraPercentile = hraPercentile;
    }
}
