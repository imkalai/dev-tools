package com.design.app.catalog.controller.joblog;

import com.design.app.catalog.api.joblog.JobLogApi;
import com.design.app.catalog.model.account.Account;
import com.design.app.catalog.model.employee.Employment;
import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.joblog.JobLog;
import com.design.app.catalog.model.team.Manager;
import com.design.app.catalog.model.team.Structure;
import com.design.app.catalog.model.team.Team;
import com.design.app.catalog.repository.account.AccountRepository;
import com.design.app.catalog.repository.employee.EmployeeRepository;
import com.design.app.catalog.repository.employee.EmploymentRepository;
import com.design.app.catalog.repository.employee.NameRepository;
import com.design.app.catalog.repository.joblog.JobLogRepository;
import com.design.app.catalog.repository.team.ManagerRepository;
import com.design.app.catalog.repository.team.TeamRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@RestController
public class JobLogController implements JobLogApi {

    @Autowired
    JobLogRepository repository;

    @Autowired
    ManagerRepository managerRepository;

    @Autowired
    TeamRepository teamRepository;

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    EmploymentRepository employmentRepository;

    @Autowired
    NameRepository nameRepository;

    @Override
    public ResponseEntity<List<JobLog>> getAllJobLog() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<?> createJobLog(JobLog jobLog) {
        try {
            if (validateJobLog(jobLog)) {
                Name name = nameRepository.findByEmployeeCode(jobLog.getName().getEmployeeCode());
                if (name != null) {
                    Name mgrName = nameRepository.findByEmployeeCode(jobLog.getManager().getName().getEmployeeCode());
                    if (mgrName != null) {
                        Manager manager = managerRepository.findByName(mgrName);
                        if (manager != null) {
                            Account account = accountRepository.findByName(jobLog.getAccount().getName());
                            if (account != null) {
                                jobLog.setEmployeeCode(employmentRepository.findByName(name).getEmployeeCode());
                                jobLog.setName(name);
                                jobLog.setManager(manager);
                                jobLog.setAccount(account);
                                return ResponseEntity.ok(repository.saveAndFlush(jobLog));
                            }
                        }
                    }
                }
            }
            return ResponseEntity.badRequest().body("Validation Failed.");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> createJobLogBatch(List<JobLog> jobLogs) {
        List<JobLog> successJobLogs = new ArrayList<>();
        List<JobLog> failedJobLogs = new ArrayList<>();
        try {
            for (JobLog jobLog : jobLogs) {
                if (validateJobLog(jobLog)) {
                    Name name = nameRepository.findByEmployeeCode(jobLog.getName().getEmployeeCode());
                    if (name != null) {
                        Name mgrName = nameRepository.findByEmployeeCode(jobLog.getManager().getName().getEmployeeCode());
                        if (mgrName != null) {
                            Manager manager = managerRepository.findByName(mgrName);
                            if (manager != null) {
                                Account account = accountRepository.findByName(jobLog.getAccount().getName());
                                if (account != null) {
                                    jobLog.setEmployeeCode(employmentRepository.findByName(name).getEmployeeCode());
                                    jobLog.setName(name);
                                    jobLog.setManager(manager);
                                    jobLog.setAccount(account);
                                    successJobLogs.add(repository.saveAndFlush(jobLog));
                                }
                            }
                        }
                    }
                } else
                    failedJobLogs.add(jobLog);
            }
            return ResponseEntity.ok("Successful Entries:\n" + successJobLogs + "\n\n" + " Failed Entries:\n" + failedJobLogs);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> editJobLog(long jobLog_id, JobLog jobLog) {
        try {
            JobLog oldJobLog = repository.findById(jobLog_id);

            Name name = nameRepository.findByEmployeeCode(jobLog.getName().getEmployeeCode());
            if (name != null) {

                Name mgrName = nameRepository.findByEmployeeCode(jobLog.getManager().getName().getEmployeeCode());
                if (mgrName != null) {
                    Manager manager = managerRepository.findByName(mgrName);

                    Account account = accountRepository.findByName(jobLog.getAccount().getName());
                    if (account != null) {
                        BeanUtils.copyProperties(jobLog, oldJobLog);
                        oldJobLog.setName(name);
                        oldJobLog.setManager(manager);
                        oldJobLog.setAccount(account);
                        oldJobLog.setAccount(account);
                        return ResponseEntity.ok(repository.save(oldJobLog));
                    }

                }
            }
            return ResponseEntity.badRequest().body("Bad Request. Validation Failed");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> deleteJobLog(long jobLog_id) {
        try {
            repository.delete(repository.findById(jobLog_id));
            return ResponseEntity.ok("Team removed successfully");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getJobLog(long jobLog_id) {
        try {
            JobLog jobLog = repository.findById(jobLog_id);
            if (jobLog != null)
                return ResponseEntity.ok(jobLog);
            else
                return ResponseEntity.badRequest().body("JobLog not exists.");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getAccountStructure(long name_id) {
        try {
            Name name = nameRepository.findById(name_id);
            Team team = teamRepository.findByName(name);
            Manager manager = managerRepository.findByName(team.getManager().getName());
            List<Account> accounts = accountRepository.findByDepartment_Name(manager.getDepartment().getName());
            Structure structure = new Structure();
            structure.setManager(manager);
            structure.setDepartment(manager.getDepartment());
            structure.setAccounts(accounts);
            return ResponseEntity.ok(structure);

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getJobLogByEmployee(String empCode, String status) {
        try {
            Employment employment = employmentRepository.findByEmployeeCode(empCode);
            if (employment != null) {
                if(status.contentEquals("any")){
                    return ResponseEntity.ok(repository.findByStatusNotLike("Pending Approval"));
                }
                else
                {
                    return ResponseEntity.ok(repository.findByStatusEquals("Pending Approval"));
                }
//                return ResponseEntity.ok(status=="any"?repository.findByStatusNotContaining("Pending"):repository.findByStatusContains("Pending"));
            }
            return ResponseEntity.badRequest().body("Bad Request. Employee code doesn't exists");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getJobLogByEmployeeByPeriod(String empCode, String year, String month, String status) {
        try {
            Employment employment = employmentRepository.findByEmployeeCode(String.valueOf(empCode));
            if (employment != null) {
                List<JobLog> joblogs=repository.getJobLogByEmployeeByPeriod(employment.getName().getId(), Long.parseLong(year) ,  Long.parseLong(month), status);
                return ResponseEntity.ok(joblogs);
            }
            return ResponseEntity.badRequest().body("Bad Request. Employee code doesn't exists");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    private boolean validateJobLog(JobLog jobLog) {
        try {
            Name name = nameRepository.findByEmployeeCode(jobLog.getName().getEmployeeCode());
            if (name != null) {
                Name mgrName = nameRepository.findByEmployeeCode(jobLog.getManager().getName().getEmployeeCode());
                if (mgrName != null) {
                    Manager manager = managerRepository.findByName(mgrName);
                    if (manager != null) {
                        Account account = accountRepository.findByName(jobLog.getAccount().getName());
                        if (account != null) {
                            return true;
                        }
                    }
                }
            }
        } catch (Exception ex) {
            return false;
        }
        return false;
    }

}
