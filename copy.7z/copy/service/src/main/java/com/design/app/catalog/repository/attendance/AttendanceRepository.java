package com.design.app.catalog.repository.attendance;

import com.design.app.catalog.model.attendance.Attendance;
import com.design.app.catalog.model.department.Department;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findAll();

    Attendance findById(long id);
}