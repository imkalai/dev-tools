package com.design.app.catalog.repository.employee;


import com.design.app.catalog.model.employee.Accounts;
import com.design.app.catalog.model.employee.Name;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigInteger;
import java.util.List;

public interface AccountsRepository extends JpaRepository<Accounts, Long> {
    List<Accounts> findAll();

    Accounts findById(long id);

    Accounts findByName(Name name);

    Accounts findByAccountNumber(long accountNumber);

    List<Accounts> findByBankName (String bankName);

}