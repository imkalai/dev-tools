package com.design.app.catalog.controller.department;



import com.design.app.catalog.api.department.DepartmentApi;
import com.design.app.catalog.model.department.Department;
import com.design.app.catalog.repository.department.DepartmentRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class DepartmentController implements DepartmentApi {

    @Autowired
    DepartmentRepository repository;

    @Override
    public ResponseEntity<List<Department>> getAllDepartment() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<Department> createDepartment(Department department) {
        return ResponseEntity.ok(repository.saveAndFlush(department));
    }

    @Override
    public ResponseEntity<List<Department>> createDepartmentBatch(List<Department> departments) {
        for (Department department: departments) {
//            department.setCreatedDateTime(LocalDateTime.now());
//            department.setLastModifiedDateTime(LocalDateTime.now());
        }
        return ResponseEntity.ok(repository.saveAll(departments));
    }

    @Override
    public ResponseEntity<Department> editDepartment(long department_id, Department department) {
        Department oldDepartment = repository.findById(department_id);
        BeanUtils.copyProperties(department,oldDepartment);
        return ResponseEntity.ok(repository.save(oldDepartment));
    }

    @Override
    public ResponseEntity<String> deleteDepartment(long department_id) {
        repository.delete(repository.findById(department_id));
        return ResponseEntity.ok("Department removed successfully");
    }

    @Override
    public ResponseEntity<Department> getDepartment(String department) {
        return ResponseEntity.ok(repository.findByName(department));
    }
}
