package com.design.app.catalog.repository.theme;

import com.design.app.catalog.model.department.Department;
import com.design.app.catalog.model.theme.Theme;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ThemeRepository extends JpaRepository<Theme, Long> {
    List<Theme> findAll();

    Theme findById(long id);

    Theme findByName(String name);
}