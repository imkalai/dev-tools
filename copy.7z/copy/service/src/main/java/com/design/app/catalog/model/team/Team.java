package com.design.app.catalog.model.team;

import com.design.app.catalog.model.employee.Name;

import javax.persistence.*;

@Entity
@Table(name = "team")
public class Team {
    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @ManyToOne
    @JoinColumn(name = "manager_id")
    private Manager manager;

    @ManyToOne
    @JoinColumn(name = "name_id")
    private Name name;

    public Team() {
    }

    public long getId() {
        return Id;
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }
}
