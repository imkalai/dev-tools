package com.design.app.catalog.api.team;

import com.design.app.catalog.model.team.Team;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "Team API", tags = {"Team"}, description = "Team API")
@RequestMapping(value = "/app/catalog")
public interface TeamApi {

    @ApiOperation(value = "Gets all teams",
            notes = "Returns all teams from db",
            response = Team.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of teams", response = Team.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/team/all",
            method = RequestMethod.GET)
    ResponseEntity<List<Team>> getAllTeam();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new Team",
            notes = "Creates a new team",
            response = Team.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Team Details", response = Team.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/team/add",
            method = RequestMethod.POST)
    ResponseEntity<?> createTeam(@ApiParam(value = "", required = true) @RequestBody Team team);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of Teams",
            notes = "Creates a set of Teams",
            response = Team.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Team Details", response = Team.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/team/add/batch",
            method = RequestMethod.POST)
    ResponseEntity<?> createTeamBatch(@ApiParam(value = "", required = true) @RequestBody List<Team> teams);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing Team",
            notes = "Edit an existing team",
            response = Team.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Team Details", response = Team.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/team/{id}",
            method = RequestMethod.PUT)
    ResponseEntity<?> editTeam(@ApiParam(value = "", required = true) @PathVariable("id") long team_id,
                               @ApiParam(value = "", required = true) @RequestBody Team team);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing Team",
            notes = "Delete an existing team",
            response = Team.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Team Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/team/{id}",
            method = RequestMethod.DELETE)
    ResponseEntity<String> deleteTeam(@ApiParam(value = "", required = true) @PathVariable("id") long team_id);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing Team",
            notes = "Gets an existing team",
            response = Team.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Team Details", response = Team.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/team/{id}",
            method = RequestMethod.GET)
    ResponseEntity<?> getTeam(@ApiParam(value = "", required = true) @PathVariable("id") long team_id);

}
