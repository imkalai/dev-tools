package com.design.app.catalog.model.employee;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "statuatory")
public class Statuatory {

    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "name_id")
    private Name name;

    private String aadhar;
    private String aadharName;
    private String pan;
    private String panName;
    private String uan;
    private String uanStatus;
    private String pfNumber;
    private LocalDate pfJoiningDate;
    private String esiNumber;
    private LocalDate esiJoiningDate;

    public Statuatory() {
    }

    public long getId() {
        return Id;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public String getAadhar() {
        return aadhar;
    }

    public void setAadhar(String aadhar) {
        this.aadhar = aadhar;
    }

    public String getAadharName() {
        return aadharName;
    }

    public void setAadharName(String aadharName) {
        this.aadharName = aadharName;
    }

    public String getPan() {
        return pan;
    }

    public void setPan(String pan) {
        this.pan = pan;
    }

    public String getPanName() {
        return panName;
    }

    public void setPanName(String panName) {
        this.panName = panName;
    }

    public String getUan() {
        return uan;
    }

    public void setUan(String uan) {
        this.uan = uan;
    }

    public String getUanStatus() {
        return uanStatus;
    }

    public void setUanStatus(String uanStatus) {
        this.uanStatus = uanStatus;
    }

    public String getPfNumber() {
        return pfNumber;
    }

    public void setPfNumber(String pfNumber) {
        this.pfNumber = pfNumber;
    }

    public LocalDate getPfJoiningDate() {
        return pfJoiningDate;
    }

    public void setPfJoiningDate(LocalDate pfJoiningDate) {
        this.pfJoiningDate = pfJoiningDate;
    }

    public String getEsiNumber() {
        return esiNumber;
    }

    public void setEsiNumber(String esiNumber) {
        this.esiNumber = esiNumber;
    }

    public LocalDate getEsiJoiningDate() {
        return esiJoiningDate;
    }

    public void setEsiJoiningDate(LocalDate esiJoiningDate) {
        this.esiJoiningDate = esiJoiningDate;
    }
}
