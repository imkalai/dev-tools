package com.design.app.catalog.model.team;

import com.design.app.catalog.model.account.Account;
import com.design.app.catalog.model.department.Department;

import java.util.List;

public class Structure {

    private Manager manager;
    private Department department;
    private List<Account> accounts;

    public Structure() {
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public List<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }
}
