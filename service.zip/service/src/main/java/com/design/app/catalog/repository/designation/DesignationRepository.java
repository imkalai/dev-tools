package com.design.app.catalog.repository.designation;


import com.design.app.catalog.model.designation.Designation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DesignationRepository extends JpaRepository<Designation, Long> {
    List<Designation> findAll();

    Designation findById(long id);

    Designation findByName(String designationName);

    Designation findByAlias(String aliasName);
}