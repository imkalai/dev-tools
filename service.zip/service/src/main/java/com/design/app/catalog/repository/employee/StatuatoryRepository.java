package com.design.app.catalog.repository.employee;


import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.employee.Statuatory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StatuatoryRepository extends JpaRepository<Statuatory, Long> {
    List<Statuatory> findAll();

    Statuatory findById(long id);

    Statuatory findByName(Name name);

    List<Statuatory> findByAadharContains(String aadhar);

    List<Statuatory> findByPanContains(String pan);

    List<Statuatory> findByUanContains(String uan);
}