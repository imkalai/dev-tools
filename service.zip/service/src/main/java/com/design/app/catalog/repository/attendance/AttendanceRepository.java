package com.design.app.catalog.repository.attendance;

import com.design.app.catalog.model.attendance.Attendance;
import com.design.app.catalog.model.department.Department;
import com.design.app.catalog.model.payroll.PayrollCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    List<Attendance> findAll();

    Attendance findById(long id);

    @Query(value = "select * from attendance a where a.emp_code = ?1 and a.date >= ?2 and a.date <= ?3", nativeQuery = true)
    List<Attendance> getAttendances(String empCode, LocalDate fromDate, LocalDate endDate);
}