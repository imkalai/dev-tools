package com.design.app.catalog.repository.team;

import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.team.Manager;
import com.design.app.catalog.model.team.Team;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TeamRepository extends JpaRepository<Team, Long> {
    List<Team> findAll();

    Team findById(long id);

    Team findByName(Name name);
}
