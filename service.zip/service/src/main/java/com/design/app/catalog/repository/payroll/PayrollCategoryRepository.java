package com.design.app.catalog.repository.payroll;

import com.design.app.catalog.model.payroll.PayrollCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PayrollCategoryRepository extends JpaRepository<PayrollCategory, Long> {
    List<PayrollCategory> findAll();

    PayrollCategory findById(long id);

    PayrollCategory findByCategory(String category);

    @Query(value = "select * from payrollcategory p where ?1 between p.start_range and p.end_range", nativeQuery = true)
    PayrollCategory getPayrollCategory(double monthly);
}