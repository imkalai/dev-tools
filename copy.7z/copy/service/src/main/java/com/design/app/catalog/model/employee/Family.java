package com.design.app.catalog.model.employee;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "family")
public class Family {

    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "name_id")
    private Name name;

    private String fatherName;
    private LocalDate fatherDob;
    private String fatherAadhar;

    private String motherName;
    private LocalDate motherDob;
    private String motherAadhar;

    private String spouseName;
    private LocalDate spouseDob;
    private String spouseAadhar;

    private String kid1Name;
    private LocalDate kid1Dob;
    private String kid1Aadhar;

    private String kid2Name;
    private LocalDate kid2Dob;
    private String kid2Aadhar;

    private String emergencyContact;
    private String emergencyNumber;

    public Family() {
    }

    public long getId() {
        return Id;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public String getFatherName() {
        return fatherName;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public LocalDate getFatherDob() {
        return fatherDob;
    }

    public void setFatherDob(LocalDate fatherDob) {
        this.fatherDob = fatherDob;
    }

    public String getFatherAadhar() {
        return fatherAadhar;
    }

    public void setFatherAadhar(String fatherAadhar) {
        this.fatherAadhar = fatherAadhar;
    }

    public String getMotherName() {
        return motherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public LocalDate getMotherDob() {
        return motherDob;
    }

    public void setMotherDob(LocalDate motherDob) {
        this.motherDob = motherDob;
    }

    public String getMotherAadhar() {
        return motherAadhar;
    }

    public void setMotherAadhar(String motherAadhar) {
        this.motherAadhar = motherAadhar;
    }

    public String getSpouseName() {
        return spouseName;
    }

    public void setSpouseName(String spouseName) {
        this.spouseName = spouseName;
    }

    public LocalDate getSpouseDob() {
        return spouseDob;
    }

    public void setSpouseDob(LocalDate spouseDob) {
        this.spouseDob = spouseDob;
    }

    public String getSpouseAadhar() {
        return spouseAadhar;
    }

    public void setSpouseAadhar(String spouseAadhar) {
        this.spouseAadhar = spouseAadhar;
    }

    public String getKid1Name() {
        return kid1Name;
    }

    public void setKid1Name(String kid1Name) {
        this.kid1Name = kid1Name;
    }

    public LocalDate getKid1Dob() {
        return kid1Dob;
    }

    public void setKid1Dob(LocalDate kid1Dob) {
        this.kid1Dob = kid1Dob;
    }

    public String getKid1Aadhar() {
        return kid1Aadhar;
    }

    public void setKid1Aadhar(String kid1Aadhar) {
        this.kid1Aadhar = kid1Aadhar;
    }

    public String getKid2Name() {
        return kid2Name;
    }

    public void setKid2Name(String kid2Name) {
        this.kid2Name = kid2Name;
    }

    public LocalDate getKid2Dob() {
        return kid2Dob;
    }

    public void setKid2Dob(LocalDate kid2Dob) {
        this.kid2Dob = kid2Dob;
    }

    public String getKid2Aadhar() {
        return kid2Aadhar;
    }

    public void setKid2Aadhar(String kid2Aadhar) {
        this.kid2Aadhar = kid2Aadhar;
    }

    public String getEmergencyContact() {
        return emergencyContact;
    }

    public void setEmergencyContact(String emergencyContact) {
        this.emergencyContact = emergencyContact;
    }

    public String getEmergencyNumber() {
        return emergencyNumber;
    }

    public void setEmergencyNumber(String emergencyNumber) {
        this.emergencyNumber = emergencyNumber;
    }
}
