package com.design.app.catalog.model.employee;

import javax.persistence.*;

@Entity
@Table(name = "employee")
public class Employee {

    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @ManyToOne
    @JoinColumn(name = "name_id")
    private Name name;

    @ManyToOne
    @JoinColumn(name = "personal_id")
    private Personal personalDetails;

    @ManyToOne
    @JoinColumn(name = "employment_id")
    private Employment employmentDetails;

    @ManyToOne
    @JoinColumn(name = "accounts_id")
    private Accounts accountDetails;

    @ManyToOne
    @JoinColumn(name = "statuatory_id")
    private Statuatory statuatoryDetails;

    @ManyToOne
    @JoinColumn(name = "education_id")
    private Education educationDetails;

    @ManyToOne
    @JoinColumn(name = "family_id")
    private Family familyDetails;

    @ManyToOne
    @JoinColumn(name = "assets_id")
    private Assets assetDetails;

    @ManyToOne
    @JoinColumn(name = "certificates_id")
    private Certificates certificateDetails;

    public Employee() {
    }

    public long getId() {
        return Id;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public Personal getPersonalDetails() {
        return personalDetails;
    }

    public void setPersonalDetails(Personal personalDetails) {
        this.personalDetails = personalDetails;
    }

    public Employment getEmploymentDetails() {
        return employmentDetails;
    }

    public void setEmploymentDetails(Employment employmentDetails) {
        this.employmentDetails = employmentDetails;
    }

    public Accounts getAccountDetails() {
        return accountDetails;
    }

    public void setAccountDetails(Accounts accountDetails) {
        this.accountDetails = accountDetails;
    }

    public Statuatory getStatuatoryDetails() {
        return statuatoryDetails;
    }

    public void setStatuatoryDetails(Statuatory statuatoryDetails) {
        this.statuatoryDetails = statuatoryDetails;
    }

    public Education getEducationDetails() {
        return educationDetails;
    }

    public void setEducationDetails(Education educationDetails) {
        this.educationDetails = educationDetails;
    }

    public Family getFamilyDetails() {
        return familyDetails;
    }

    public void setFamilyDetails(Family familyDetails) {
        this.familyDetails = familyDetails;
    }

    public Assets getAssetDetails() {
        return assetDetails;
    }

    public void setAssetDetails(Assets assetDetails) {
        this.assetDetails = assetDetails;
    }

    public Certificates getCertificateDetails() {
        return certificateDetails;
    }

    public void setCertificateDetails(Certificates certificateDetails) {
        this.certificateDetails = certificateDetails;
    }
}
