package com.design.app.catalog.helpers;

import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class PayrollHelper {

    public PayrollHelper() {
    }

    public String getWorkMonth(LocalDate workDate) {
        if (workDate.getDayOfMonth() <= 31 && workDate.getDayOfMonth() >= 16)
            return workDate.getMonth().name();
        else
            return workDate.getMonth().minus(1).name();
    }

    public int getWorkYear(LocalDate workDate) {
        if (workDate.getMonth().toString().toLowerCase().equals ("january") && (workDate.getDayOfMonth() >= 01 && workDate.getDayOfMonth() <= 15))
            return workDate.getYear()-1;
        else
            return workDate.getYear();
    }
}
