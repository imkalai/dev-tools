package com.design.app.catalog.controller.account;


import com.design.app.catalog.api.account.AccountApi;
import com.design.app.catalog.model.account.Account;
import com.design.app.catalog.model.department.Department;
import com.design.app.catalog.repository.account.AccountRepository;
import com.design.app.catalog.repository.department.DepartmentRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class AccountController implements AccountApi {

    @Autowired
    AccountRepository repository;

    @Autowired
    DepartmentRepository departmentRepository;

    @Override
    public ResponseEntity<List<Account>> getAllAccount() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<?> createAccount(Account account) {
        try {
            if (validateAccount(account))
                return ResponseEntity.ok(repository.saveAndFlush(account));
            else
                return ResponseEntity.badRequest().body("Bad Request. Validation Failed");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> createAccountBatch(List<Account> accounts) {
        List<Account> successAccounts = new ArrayList<>();
        List<Account> failedAccounts = new ArrayList<>();
        try {
            for (Account account : accounts) {
                if (validateAccount(account))
                    successAccounts.add(repository.saveAndFlush(account));
                else
                    failedAccounts.add(account);

            }
            return ResponseEntity.ok("Success Accounts:\n" + successAccounts.toString() + "\n\n"
                    + " Failed Accounts:\n" + failedAccounts.toString());
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> editAccount(long account_id, Account account) {
        try {
            Account oldAccount = repository.findById(account_id);
            BeanUtils.copyProperties(account, oldAccount);
            return ResponseEntity.ok(repository.save(oldAccount));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> deleteAccount(long account_id) {
        try {
            repository.delete(repository.findById(account_id));
            return ResponseEntity.ok("Account removed successfully");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getAccount(String account) {
        try {
            return ResponseEntity.ok(repository.findByName(account));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    private boolean validateAccount(Account account) {
        Department department = departmentRepository.findByName(account.getDepartment().getName());
        if (department != null) {
            account.setDepartment(department);
            return true;
        }
        return false;
    }
}
