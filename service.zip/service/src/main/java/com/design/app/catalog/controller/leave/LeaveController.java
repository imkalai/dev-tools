package com.design.app.catalog.controller.leave;

import com.design.app.catalog.api.leave.LeaveApi;
import com.design.app.catalog.model.account.Account;
import com.design.app.catalog.model.employee.Employment;
import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.joblog.JobLog;
import com.design.app.catalog.model.leave.Leave;
import com.design.app.catalog.model.team.Manager;
import com.design.app.catalog.repository.account.AccountRepository;
import com.design.app.catalog.repository.employee.EmployeeRepository;
import com.design.app.catalog.repository.employee.EmploymentRepository;
import com.design.app.catalog.repository.employee.NameRepository;
import com.design.app.catalog.repository.joblog.JobLogRepository;
import com.design.app.catalog.repository.leave.LeaveRepository;
import com.design.app.catalog.repository.team.ManagerRepository;
import com.design.app.catalog.repository.team.TeamRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class LeaveController implements LeaveApi {

    @Autowired
    LeaveRepository repository;

    @Autowired
    ManagerRepository managerRepository;

    @Autowired
    TeamRepository teamRepository;

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    EmployeeRepository employeeRepository;

    @Autowired
    EmploymentRepository employmentRepository;

    @Autowired
    NameRepository nameRepository;

    @Override
    public ResponseEntity<List<Leave>> getAllLeave() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<?> createLeave(Leave leave) {
        try {
            if (validateLeave(leave)) {
                Name name = nameRepository.findByEmployeeCode(leave.getName().getEmployeeCode());
                if (name != null) {
                    Name mgrName = nameRepository.findByEmployeeCode(leave.getManager().getName().getEmployeeCode());
                    if (mgrName != null) {
                        Manager manager = managerRepository.findByName(mgrName);
                        if (manager != null) {
                            leave.setEmployeeCode(employmentRepository.findByName(name).getEmployeeCode());
                            leave.setName(name);
                            leave.setManager(manager);
                            return ResponseEntity.ok(repository.saveAndFlush(leave));
                        }
                    }
                }
            }
            return ResponseEntity.badRequest().body("Validation Failed.");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> createLeaveBatch(List<Leave> leaves) {
        List<Leave> successLeaves = new ArrayList<>();
        List<Leave> failedLeaves = new ArrayList<>();
        try {
            for (Leave leave : leaves) {
                if (validateLeave(leave)) {
                    Name name = nameRepository.findByEmployeeCode(leave.getName().getEmployeeCode());
                    if (name != null) {
                        Name mgrName = nameRepository.findByEmployeeCode(leave.getManager().getName().getEmployeeCode());
                        if (mgrName != null) {
                            Manager manager = managerRepository.findByName(mgrName);
                            if (manager != null) {
                                leave.setEmployeeCode(employmentRepository.findByName(name).getEmployeeCode());
                                leave.setName(name);
                                leave.setManager(manager);
                                successLeaves.add(repository.saveAndFlush(leave));
                            }
                        }
                    }
                } else
                    failedLeaves.add(leave);
            }
            return ResponseEntity.ok("Successful Entries:\n" + successLeaves + "\n\n" + " Failed Entries:\n" + failedLeaves);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> editLeave(long leave_id, Leave leave) {
        try {
            Leave oldLeave = repository.findById(leave_id);

            Name name = nameRepository.findByEmployeeCode(leave.getName().getEmployeeCode());
            if (name != null) {

                Name mgrName = nameRepository.findByEmployeeCode(leave.getManager().getName().getEmployeeCode());
                if (mgrName != null) {

                    Manager manager = managerRepository.findByName(mgrName);
                    if(manager!=null) {
                        BeanUtils.copyProperties(leave, oldLeave);
                        oldLeave.setName(name);
                        oldLeave.setManager(manager);
                    }
                    return ResponseEntity.ok(repository.save(oldLeave));
                }
            }
            return ResponseEntity.badRequest().body("Bad Request. Validation Failed");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> deleteLeave(long leave_id) {
        try {
            repository.delete(repository.findById(leave_id));
            return ResponseEntity.ok("Leave removed successfully");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getLeave(long leave_id) {
        try {
            Leave leave = repository.findById(leave_id);
            if (leave != null)
                return ResponseEntity.ok(leave);
            else
                return ResponseEntity.badRequest().body("Leave not exists.");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getLeaveByEmployee(String empCode, String status) {
        try {
            Employment employment = employmentRepository.findByEmployeeCode(empCode);
            if (employment != null) {
                if(status.contentEquals("any")){
                    return ResponseEntity.ok(repository.findByStatusNotLike("Pending Approval"));
                }
                else
                {
                    return ResponseEntity.ok(repository.findByStatusEquals("Pending Approval"));
                }
//                return ResponseEntity.ok(status=="any"?repository.findByStatusNotContaining("Pending"):repository.findByStatusContains("Pending"));
            }
            return ResponseEntity.badRequest().body("Bad Request. Employee code doesn't exists");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getLeaveByEmployeeByPeriod(String empCode, String year, String month, String status) {
        try {
            Employment employment = employmentRepository.findByEmployeeCode(String.valueOf(empCode));
            if (employment != null) {
                List<Leave> leaves=repository.getLeaveByEmployeeByPeriod(employment.getName().getId(), Long.parseLong(year) ,  Long.parseLong(month), status);
                return ResponseEntity.ok(leaves);
            }
            return ResponseEntity.badRequest().body("Bad Request. Employee code doesn't exists");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    private boolean validateLeave(Leave leave) {
        try {
            Name name = nameRepository.findByFirstNameEqualsAndLastNameEquals(leave.getName().getFirstName(),
                    leave.getName().getLastName());
            if (name != null) {
                Name mgrName = nameRepository.findByFirstNameEqualsAndLastNameEquals(leave.getManager().getName().getFirstName(),
                        leave.getManager().getName().getLastName());
                if (mgrName != null) {
                    Manager manager = managerRepository.findByName(mgrName);
                    if (manager != null) {
                            return true;
                    }
                }
            }
        } catch (Exception ex) {
            return false;
        }
        return false;
    }
}
