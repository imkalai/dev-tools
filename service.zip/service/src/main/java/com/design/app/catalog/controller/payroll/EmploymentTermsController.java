package com.design.app.catalog.controller.payroll;

import com.design.app.catalog.api.payroll.EmploymentTermsApi;
import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.payroll.EmploymentTerms;
import com.design.app.catalog.repository.employee.NameRepository;
import com.design.app.catalog.repository.payroll.EmploymentTermsRepository;
import com.design.app.catalog.repository.payroll.PayrollCategoryRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import java.util.ArrayList;
import java.util.List;

@Controller
public class EmploymentTermsController implements EmploymentTermsApi {

    @Autowired
    EmploymentTermsRepository repository;

    @Autowired
    PayrollCategoryRepository payrollCategoryRepository;

    @Autowired
    NameRepository nameRepository;

    @Override
    public ResponseEntity<List<EmploymentTerms>> getAllEmploymentTerms() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<?> createEmploymentTerms(EmploymentTerms employmentterms) {
        try {
            if (checkIfNotExists(employmentterms)) {
                EmploymentTerms processedTerms = getProcessedTerms(employmentterms);
                return ResponseEntity.ok(repository.saveAndFlush(processedTerms));
            }
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
        return ResponseEntity.badRequest().body("Unable to load Employment Terms. Failed at 'checkIfNotExists'");
    }

    @Override
    public ResponseEntity<?> createEmploymentTermsBatch(List<EmploymentTerms> employmentTerms) {
        List<EmploymentTerms> successTerms = new ArrayList<>();
        List<EmploymentTerms> failedTerms = new ArrayList<>();
        try {
            for (EmploymentTerms employmentTerm : employmentTerms) {
                if (checkIfNotExists(employmentTerm)) {
                    EmploymentTerms processedTerms = getProcessedTerms(employmentTerm);
                    successTerms.add(repository.saveAndFlush(processedTerms));
                } else
                    failedTerms.add(employmentTerm);
            }

            return ResponseEntity.ok("Success Terms:\n" + successTerms + "\n\n" + " Failed Terms:\n" + failedTerms);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    private EmploymentTerms getProcessedTerms(EmploymentTerms employmentTerm) {
        try {

            double monthly = employmentTerm.getMonthly();
            employmentTerm.setAnnual(monthly * 12);
            String category = payrollCategoryRepository.getPayrollCategory(monthly).getCategory();
            employmentTerm.setCategory(category);
            switch (category) {
                case "A":
                    employmentTerm.setFixedBasic(Math.round(monthly * 0.61));
                    employmentTerm.setFixedDa(Math.round(monthly * 0.39));
                    employmentTerm.setFixedHra(0);
                    break;
                case "B":
                    employmentTerm.setFixedBasic(Math.round(monthly * 0.55));
                    employmentTerm.setFixedDa(Math.round(monthly * 0.45));
                    employmentTerm.setFixedHra(0);
                    break;
                case "C":
                    employmentTerm.setFixedBasic(Math.round(monthly * 0.45));
                    employmentTerm.setFixedDa(Math.round(monthly * 0.35));
                    employmentTerm.setFixedHra(Math.round(monthly * 0.20));
                    break;
                case "D":
                    employmentTerm.setFixedBasic(Math.round(monthly * 0.35));
                    employmentTerm.setFixedDa(Math.round(monthly * 0.35));
                    employmentTerm.setFixedHra(Math.round(monthly * 0.30));
                    break;
            }
            return employmentTerm;
        } catch (Exception ex) {
            throw ex;
        }
    }

    @Override
    public ResponseEntity<?> editEmploymentTerms(long employmentterms_id, EmploymentTerms employmentterms) {
        try {
            EmploymentTerms oldEmploymentTerms = repository.findById(employmentterms_id);
            BeanUtils.copyProperties(employmentterms, oldEmploymentTerms);
            return ResponseEntity.ok(repository.save(oldEmploymentTerms));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> deleteEmploymentTerms(long employmentterms_id) {
        try {
            repository.delete(repository.findById(employmentterms_id));
            return ResponseEntity.ok("Employment Terms removed successfully");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getEmploymentTerms(String empCode) {
        try {
            return ResponseEntity.ok(repository.findByEmpCode(empCode));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    private boolean checkIfNotExists(EmploymentTerms value) {
        Name name = nameRepository.findByEmployeeCode(value.getEmpCode());
        if(name!=null) {
            EmploymentTerms employmentTerms = repository.findByEmpCode(value.getEmpCode());
            if (employmentTerms == null) {
                return true;
            }
        }
        return false;
    }
}
