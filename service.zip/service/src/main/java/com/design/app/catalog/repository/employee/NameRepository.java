package com.design.app.catalog.repository.employee;


import com.design.app.catalog.model.employee.Name;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NameRepository extends JpaRepository<Name, Long> {
    List<Name> findAll();

    Name findById(long id);

    List<Name> findByFirstNameContains(String firstName);

    Name findByFirstNameEqualsAndLastNameEquals(String firstName, String lastName);

    Name findByEmployeeCode(String employeeCode);
}