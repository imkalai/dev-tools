package com.design.app.catalog.repository.team;

import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.team.Manager;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ManagerRepository extends JpaRepository<Manager, Long> {
    List<Manager> findAll();

    Manager findById(long id);

    Manager findByName(Name name);


}
