package com.design.app.catalog.api.employee;


import com.design.app.catalog.model.employee.Name;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "Name API", tags = {"Name"}, description = "Name API")
@RequestMapping(value = "/app/catalog")
public interface NameApi {

    @ApiOperation(value = "Gets all Names",
            notes = "Returns all Names from db",
            response = Name.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of Categories", response = Name.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/name/all",
            method= RequestMethod.GET)
    ResponseEntity<List<Name>> getAllNames();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new Name",
            notes = "Creates a new Name",
            response = Name.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Name Details", response = Name.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/name/add",
            method= RequestMethod.POST)
    ResponseEntity<?> createName(@ApiParam(value = "", required = true) @RequestBody Name name);
/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of names",
            notes = "Creates a set of names",
            response = Name.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Name Details", response = Name.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/name/add/batch",
            method= RequestMethod.POST)
    ResponseEntity<?> createNameBatch(@ApiParam(value = "", required = true) @RequestBody List<Name> names);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing Name",
            notes = "Edit an existing Name",
            response = Name.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Name Details", response = Name.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/name/{id}",
            method= RequestMethod.PUT)
    ResponseEntity<Name> editName(@ApiParam(value = "", required = true) @PathVariable("id") long name_id,
                                  @ApiParam(value = "", required = true) @RequestBody Name name);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing Name",
            notes = "Delete an existing Name",
            response = Name.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Name Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/name/{id}",
            method= RequestMethod.DELETE)
    ResponseEntity<String> deleteName(@ApiParam(value = "", required = true) @PathVariable("id") long name_id);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Gets an existing Name",
            notes = "Gets an existing Name",
            response = Name.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Name Details", response = Name.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/name/filter/{name}",
            method= RequestMethod.GET)
    ResponseEntity<List<Name>> getFilteredName(@ApiParam(value = "", required = true) @PathVariable("name") String name);



}
