package com.design.app.catalog.repository.employee;


import com.design.app.catalog.model.employee.Assets;
import com.design.app.catalog.model.employee.Name;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AssetsRepository extends JpaRepository<Assets, Long> {
    List<Assets> findAll();

    Assets findById(long id);

    Assets findByName(Name name);
}