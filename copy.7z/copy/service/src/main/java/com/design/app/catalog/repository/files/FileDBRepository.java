package com.design.app.catalog.repository.files;

import com.design.app.catalog.model.files.DataFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface FileDBRepository extends JpaRepository<DataFile, String> {

    DataFile findByName(String name);

    DataFile findByNameAndType(String name, String type);
}