package com.design.app.catalog.repository.leave;

import com.design.app.catalog.model.joblog.JobLog;
import com.design.app.catalog.model.leave.Leave;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LeaveRepository extends JpaRepository<Leave, Long> {
    List<Leave> findAll();

    Leave findById(long id);

    List<Leave> findByStatusEquals(String status);

    List<Leave> findByStatusNotLike(String status);

    @Query(value = "select * from joblog j where j.name_id=?1 and date_part('year', j.from_date)=?2 and date_part('month', j.from_date)=?3 and j.status=?4", nativeQuery = true)
    List<Leave> getLeaveByEmployeeByPeriod(long name_id, long year, long month, String status);

}

