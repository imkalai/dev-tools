package com.design.app.catalog.controller.team;

import com.design.app.catalog.api.team.ManagerApi;
import com.design.app.catalog.model.account.Account;
import com.design.app.catalog.model.department.Department;
import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.team.Manager;
import com.design.app.catalog.repository.account.AccountRepository;
import com.design.app.catalog.repository.department.DepartmentRepository;
import com.design.app.catalog.repository.employee.NameRepository;
import com.design.app.catalog.repository.team.ManagerRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ManagerController implements ManagerApi {

    @Autowired
    ManagerRepository repository;

    @Autowired
    NameRepository nameRepository;

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    @Override
    public ResponseEntity<List<Manager>> getAllManager() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<?> createManager(Manager manager) {
        try {
            if (validateManager(manager)) {
                Name name = nameRepository.findByEmployeeCode(manager.getName().getEmployeeCode()
                        );
                if (name != null) {
                    Department department = departmentRepository.findByName(manager.getDepartment().getName());
                    if (department != null) {
                        manager.setName(name);
                        manager.setDepartment(department);
                        return ResponseEntity.ok(repository.saveAndFlush(manager));
                    }
                }
            }
            return ResponseEntity.badRequest().body("Validation Failed.");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }


    @Override
    public ResponseEntity<?> createManagerBatch(List<Manager> managers) {
        List<Manager> successManagers = new ArrayList<>();
        List<Manager> failedManagers = new ArrayList<>();
        try {
            for (Manager manager : managers) {
                if (validateManager(manager)) {
                    Name name = nameRepository.findByEmployeeCode(manager.getName().getEmployeeCode());
                    if (name != null) {
                        Department department = departmentRepository.findByName(manager.getDepartment().getName());
                        if (department != null) {
                            manager.setName(name);
                            manager.setDepartment(department);
                            successManagers.add(repository.saveAndFlush(manager));
                        }
                    }
                } else
                    failedManagers.add(manager);
            }
            return ResponseEntity.ok("Successful Entries:\n" + successManagers + "\n\n" + " Failed Entries:\n" + failedManagers);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> editManager(long manager_id, Manager manager) {
        try {
            Manager oldManager = repository.findById(manager_id);
            Department department = departmentRepository.findByName(manager.getDepartment().getName());
            BeanUtils.copyProperties(manager, oldManager);
            oldManager.setDepartment(department);
            return ResponseEntity.ok(repository.save(oldManager));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> deleteManager(long manager_id) {
        try {
            repository.delete(repository.findById(manager_id));
            return ResponseEntity.ok("Manager removed successfully");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getManager(long manager_id) {
        try {
            Manager manager = repository.findById(manager_id);
            if (manager != null)
                return ResponseEntity.ok(manager);
            else
                return ResponseEntity.badRequest().body("Manager not exists.");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    private boolean validateManager(Manager manager) {
        try {
            Name name = nameRepository.findByEmployeeCode(manager.getName().getEmployeeCode());
            if (name != null) {
                    Department department = departmentRepository.findByName(manager.getDepartment().getName());
                    if (department != null) {
                        return true;
                    }

            }
        } catch (Exception ex) {
            return false;
        }
        return false;
    }
}
