package com.design.app.catalog.controller.theme;



import com.design.app.catalog.api.theme.ThemeApi;
import com.design.app.catalog.model.theme.Theme;
import com.design.app.catalog.repository.theme.ThemeRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ThemeController implements ThemeApi {

    @Autowired
    ThemeRepository repository;

    @Override
    public ResponseEntity<List<Theme>> getAllTheme() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<Theme> createTheme(Theme theme) {
        return ResponseEntity.ok(repository.saveAndFlush(theme));
    }

    @Override
    public ResponseEntity<List<Theme>> createThemeBatch(List<Theme> themes) {
        for (Theme theme: themes) {
//            theme.setCreatedDateTime(LocalDateTime.now());
//            theme.setLastModifiedDateTime(LocalDateTime.now());
        }
        return ResponseEntity.ok(repository.saveAll(themes));
    }

    @Override
    public ResponseEntity<Theme> editTheme(long theme_id, Theme theme) {
        Theme oldTheme = repository.findById(theme_id);
        BeanUtils.copyProperties(theme,oldTheme);
        return ResponseEntity.ok(repository.save(oldTheme));
    }

    @Override
    public ResponseEntity<String> deleteTheme(long theme_id) {
        repository.delete(repository.findById(theme_id));
        return ResponseEntity.ok("Theme removed successfully");
    }

    @Override
    public ResponseEntity<Theme> getTheme(String theme) {
        return ResponseEntity.ok(repository.findByName(theme));
    }
}
