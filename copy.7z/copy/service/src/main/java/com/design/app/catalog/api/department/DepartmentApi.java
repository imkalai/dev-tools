package com.design.app.catalog.api.department;


import com.design.app.catalog.model.department.Department;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "Department API", tags = {"Department"}, description = "Department API")
@RequestMapping(value = "/app/catalog")
public interface DepartmentApi {

    @ApiOperation(value = "Gets all departments",
            notes = "Returns all departments from db",
            response = Department.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of departments", response = Department.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/department/all",
            method= RequestMethod.GET)
    ResponseEntity<List<Department>> getAllDepartment();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new Department",
            notes = "Creates a new department",
            response = Department.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Department Details", response = Department.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/department/add",
            method= RequestMethod.POST)
    ResponseEntity<Department> createDepartment(@ApiParam(value = "", required = true) @RequestBody Department department);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of Departments",
            notes = "Creates a set of Departments",
            response = Department.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Department Details", response = Department.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/department/add/batch",
            method= RequestMethod.POST)
    ResponseEntity<List<Department>> createDepartmentBatch(@ApiParam(value = "", required = true) @RequestBody List<Department> departments);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing Department",
            notes = "Edit an existing department",
            response = Department.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Department Details", response = Department.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/department/{id}",
            method= RequestMethod.PUT)
    ResponseEntity<Department> editDepartment(@ApiParam(value = "", required = true) @PathVariable("id") long department_id,
                                              @ApiParam(value = "", required = true) @RequestBody Department department);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing Department",
            notes = "Delete an existing department",
            response = Department.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Department Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/department/{id}",
            method= RequestMethod.DELETE)
    ResponseEntity<String> deleteDepartment(@ApiParam(value = "", required = true) @PathVariable("id") long department_id);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing Department",
            notes = "Gets an existing department",
            response = Department.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Department Details", response = Department.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/department/{name}",
            method= RequestMethod.GET)
    ResponseEntity<Department> getDepartment(@ApiParam(value = "", required = true) @PathVariable("name") String department);

}
