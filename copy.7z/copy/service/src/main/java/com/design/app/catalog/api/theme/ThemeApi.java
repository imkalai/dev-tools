package com.design.app.catalog.api.theme;

import com.design.app.catalog.model.theme.Theme;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "Theme API", tags = {"Theme"}, description = "Theme API")
@RequestMapping(value = "/app/catalog")
public interface ThemeApi {

    @ApiOperation(value = "Gets all themes",
            notes = "Returns all themes from db",
            response = Theme.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of themes", response = Theme.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/theme/all",
            method= RequestMethod.GET)
    ResponseEntity<List<Theme>> getAllTheme();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new Theme",
            notes = "Creates a new theme",
            response = Theme.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Theme Details", response = Theme.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/theme/add",
            method= RequestMethod.POST)
    ResponseEntity<Theme> createTheme(@ApiParam(value = "", required = true) @RequestBody Theme theme);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of Themes",
            notes = "Creates a set of Themes",
            response = Theme.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Theme Details", response = Theme.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/theme/add/batch",
            method= RequestMethod.POST)
    ResponseEntity<List<Theme>> createThemeBatch(@ApiParam(value = "", required = true) @RequestBody List<Theme> themes);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing Theme",
            notes = "Edit an existing theme",
            response = Theme.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Theme Details", response = Theme.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/theme/{id}",
            method= RequestMethod.PUT)
    ResponseEntity<Theme> editTheme(@ApiParam(value = "", required = true) @PathVariable("id") long theme_id,
                                    @ApiParam(value = "", required = true) @RequestBody Theme theme);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing Theme",
            notes = "Delete an existing theme",
            response = Theme.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Theme Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/theme/{id}",
            method= RequestMethod.DELETE)
    ResponseEntity<String> deleteTheme(@ApiParam(value = "", required = true) @PathVariable("id") long theme_id);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing Theme",
            notes = "Gets an existing theme",
            response = Theme.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Theme Details", response = Theme.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/theme/{name}",
            method= RequestMethod.GET)
    ResponseEntity<Theme> getTheme(@ApiParam(value = "", required = true) @PathVariable("name") String theme);

}

