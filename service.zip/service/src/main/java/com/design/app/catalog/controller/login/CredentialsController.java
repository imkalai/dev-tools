package com.design.app.catalog.controller.login;

import com.design.app.catalog.api.login.CredentialsApi;
import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.login.Credentials;
import com.design.app.catalog.repository.employee.NameRepository;
import com.design.app.catalog.repository.login.CredentialsRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class CredentialsController implements CredentialsApi {

    @Autowired
    CredentialsRepository repository;

    @Autowired
    NameRepository nameRepository;

    @Override
    public ResponseEntity<List<Credentials>> getAllCredentials() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<?> createCredentials(Credentials credentials) {
        try {
            if (checkIfNotExists(credentials)) {
                return ResponseEntity.ok(repository.saveAndFlush(credentials));
            }
            return ResponseEntity.badRequest().body("Bad Request. Validation Failed");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }

    }

    @Override
    public ResponseEntity<?> createCredentialsBatch(List<Credentials> credentials) {
        List<Credentials> successCredentials = new ArrayList<>();
        List<Credentials> failedCredentials = new ArrayList<>();
        try {
            for (Credentials credential : credentials) {
                if (checkIfNotExists(credential)) {
                    successCredentials.add(repository.saveAndFlush(credential));
                } else
                    failedCredentials.add(credential);

            }

            return ResponseEntity.ok("Success Credentials:\n" + successCredentials + "\n\n" + " Failed Credentials:\n" + failedCredentials);
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> editCredentials(long credentials_id, Credentials credentials) {

        try {
            Credentials oldCredentials = repository.findById(credentials_id);
            Name name = nameRepository.findById(oldCredentials.getName().getId());
            BeanUtils.copyProperties(credentials, oldCredentials);
            oldCredentials.setName(name);
            return ResponseEntity.ok(repository.saveAndFlush(oldCredentials));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> deleteCredentials(long credentials_id) {
        repository.delete(repository.findById(credentials_id));
        return ResponseEntity.ok("Credentials removed successfully");
    }

    @Override
    public ResponseEntity<Credentials> getCredentials(long credentials_id) {
        return ResponseEntity.ok(repository.findById(credentials_id));
    }

    @Override
    public ResponseEntity<?> verifyCredentials(String username, String password) {
        try {
           Credentials credentials = repository.findByUsernameEqualsAndPasswordEquals(username, password);
           if(credentials!=null)
           {
               return ResponseEntity.ok("Valid Credentials");
           }
           else {
               credentials = repository.findByEmailEqualsAndPasswordEquals(username, password);
               if(credentials!=null)
               {
                   return ResponseEntity.ok("Valid Credentials");
               }
           }
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body("Invalid Credentials");
        }
        return ResponseEntity.badRequest().body("Invalid Credentials");
    }

    private boolean checkIfNotExists(Credentials credentials) {
        Name name  = nameRepository.findByEmployeeCode(credentials.getName().getEmployeeCode());
//        Name name = names.size() > 0 ? names.get(0) : null;
        if (name != null) {
            credentials.setName(name);
            return true;
        }
        return false;
    }


}
