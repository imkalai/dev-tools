package com.design.app.catalog.api.leave;

import com.design.app.catalog.model.leave.Leave;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "Leave API", tags = {"Leave"}, description = "Leave API")
@RequestMapping(value = "/app/catalog")
public interface LeaveApi {

    @ApiOperation(value = "Gets all leaves",
            notes = "Returns all leaves from db",
            response = Leave.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of leaves", response = Leave.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/leave/all",
            method = RequestMethod.GET)
    ResponseEntity<List<Leave>> getAllLeave();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new Leave",
            notes = "Creates a new leave",
            response = Leave.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Leave Details", response = Leave.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/leave/add",
            method = RequestMethod.POST)
    ResponseEntity<?> createLeave(@ApiParam(value = "", required = true) @RequestBody Leave leave);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of Leaves",
            notes = "Creates a set of Leaves",
            response = Leave.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Leave Details", response = Leave.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/leave/add/batch",
            method = RequestMethod.POST)
    ResponseEntity<?> createLeaveBatch(@ApiParam(value = "", required = true) @RequestBody List<Leave> leaves);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing Leave",
            notes = "Edit an existing leave",
            response = Leave.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Leave Details", response = Leave.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/leave/{id}",
            method = RequestMethod.PUT)
    ResponseEntity<?> editLeave(@ApiParam(value = "", required = true) @PathVariable("id") long leave_id,
                                @ApiParam(value = "", required = true) @RequestBody Leave leave);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing Leave",
            notes = "Delete an existing leave",
            response = Leave.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Leave Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/leave/{id}",
            method = RequestMethod.DELETE)
    ResponseEntity<String> deleteLeave(@ApiParam(value = "", required = true) @PathVariable("id") long leave_id);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing Leave",
            notes = "Gets an existing leave",
            response = Leave.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Leave Details", response = Leave.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/leave/{id}",
            method = RequestMethod.GET)
    ResponseEntity<?> getLeave(@ApiParam(value = "", required = true) @PathVariable("id") long leave_id);

    /////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing Leave",
            notes = "Gets an existing leave",
            response = Leave.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Leave Details", response = Leave.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/leave/employee/{empcode}/{status}",
            method = RequestMethod.GET)
    ResponseEntity<?> getLeaveByEmployee(@ApiParam(value = "", required = true) @PathVariable("empcode") String empCode,
                                         @ApiParam(value = "", required = true) @PathVariable("status") String status);
    /////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing Leave",
            notes = "Gets an existing leave",
            response = Leave.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Leave Details", response = Leave.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/leave/employee/{empcode}/{year}/{month}/{status}",
            method = RequestMethod.GET)
    ResponseEntity<?> getLeaveByEmployeeByPeriod(@ApiParam(value = "", required = true) @PathVariable("empcode") String empCode,
                                                 @ApiParam(value = "", required = true) @PathVariable("year") String year,
                                                 @ApiParam(value = "", required = true) @PathVariable("month") String month,
                                                 @ApiParam(value = "", required = true) @PathVariable("status") String status);

}

