package com.design.app.catalog.model.account;

import com.design.app.catalog.model.department.Department;

import javax.persistence.*;

@Entity
@Table(name = "account")
public class Account {
    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @ManyToOne
    @JoinColumn(name = "department_id")
    private Department department;

    private String name;


    protected Account() {
    }

    public Account(String name) {
        this.name = name;
    }

    public long getId() {
        return Id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}
