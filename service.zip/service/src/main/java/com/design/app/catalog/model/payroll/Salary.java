package com.design.app.catalog.model.payroll;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

@Entity
@Table(name = "salary")
public class Salary {
    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    private double basic;
    private double da;
    private double hra;
    private double conveyanceAllowance;
    private double specialAllowance;
    private double overtimeAllowance;
    private double shiftAllowance;
    private double otherAllowance;
    private double earnings;
    private double pf;
    private double esi;
    private double profTax;
    private double IncomeTax;
    private double welfare;
    private double otherDeduction;
    private double staffAdvance;
    private double deductions;
    private double netPay;
    private double pf_367;
    private double pf_833;
    private double esi_325;


    public Salary() {
    }

    public long getId() {
        return Id;
    }

    public double getBasic() {
        return basic;
    }

    public void setBasic(double basic) {
        this.basic = basic;
    }

    public double getDa() {
        return da;
    }

    public void setDa(double da) {
        this.da = da;
    }

    public double getHra() {
        return hra;
    }

    public void setHra(double hra) {
        this.hra = hra;
    }

    public double getConveyanceAllowance() {
        return conveyanceAllowance;
    }

    public void setConveyanceAllowance(double conveyanceAllowance) {
        this.conveyanceAllowance = conveyanceAllowance;
    }

    public double getSpecialAllowance() {
        return specialAllowance;
    }

    public void setSpecialAllowance(double specialAllowance) {
        this.specialAllowance = specialAllowance;
    }

    public double getOvertimeAllowance() {
        return overtimeAllowance;
    }

    public void setOvertimeAllowance(double overtimeAllowance) {
        this.overtimeAllowance = overtimeAllowance;
    }

    public double getShiftAllowance() {
        return shiftAllowance;
    }

    public void setShiftAllowance(double shiftAllowance) {
        this.shiftAllowance = shiftAllowance;
    }

    public double getOtherAllowance() {
        return otherAllowance;
    }

    public void setOtherAllowance(double otherAllowance) {
        this.otherAllowance = otherAllowance;
    }

    public double getEarnings() {
        return earnings;
    }

    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }

    public double getPf() {
        return pf;
    }

    public void setPf(double pf) {
        this.pf = pf;
    }

    public double getEsi() {
        return esi;
    }

    public void setEsi(double esi) {
        this.esi = esi;
    }

    public double getProfTax() {
        return profTax;
    }

    public void setProfTax(double profTax) {
        this.profTax = profTax;
    }

    public double getIncomeTax() {
        return IncomeTax;
    }

    public void setIncomeTax(double incomeTax) {
        IncomeTax = incomeTax;
    }

    public double getWelfare() {
        return welfare;
    }

    public void setWelfare(double welfare) {
        this.welfare = welfare;
    }

    public double getOtherDeduction() {
        return otherDeduction;
    }

    public void setOtherDeduction(double otherDeduction) {
        this.otherDeduction = otherDeduction;
    }

    public double getStaffAdvance() {
        return staffAdvance;
    }

    public void setStaffAdvance(double staffAdvance) {
        this.staffAdvance = staffAdvance;
    }

    public double getDeductions() {
        return deductions;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }

    public double getNetPay() {
        return netPay;
    }

    public void setNetPay(double netPay) {
        this.netPay = netPay;
    }

    public double getPf_367() {
        return pf_367;
    }

    public void setPf_367(double pf_367) {
        this.pf_367 = pf_367;
    }

    public double getPf_833() {
        return pf_833;
    }

    public void setPf_833(double pf_833) {
        this.pf_833 = pf_833;
    }

    public double getEsi_325() {
        return esi_325;
    }

    public void setEsi_325(double esi_325) {
        this.esi_325 = esi_325;
    }
}
