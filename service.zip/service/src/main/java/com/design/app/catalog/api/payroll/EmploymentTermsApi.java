package com.design.app.catalog.api.payroll;

import com.design.app.catalog.model.payroll.EmploymentTerms;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "EmploymentTerms API", tags = {"EmploymentTerms"}, description = "EmploymentTerms API")
@RequestMapping(value = "/app/catalog")
public interface EmploymentTermsApi {

    @ApiOperation(value = "Gets all employmentterms",
            notes = "Returns all employmentterms from db",
            response = EmploymentTerms.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of employmentterms", response = EmploymentTerms.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/employmentterms/all",
            method = RequestMethod.GET)
    ResponseEntity<List<EmploymentTerms>> getAllEmploymentTerms();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new EmploymentTerms",
            notes = "Creates a new employmentterms",
            response = EmploymentTerms.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "EmploymentTerms Details", response = EmploymentTerms.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/employmentterms/add",
            method = RequestMethod.POST)
    ResponseEntity<?> createEmploymentTerms(@ApiParam(value = "", required = true) @RequestBody EmploymentTerms employmentterms);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of EmploymentTerms",
            notes = "Creates a set of new employmentterms",
            response = EmploymentTerms.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "EmploymentTerms Details", response = EmploymentTerms.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/employmentterms/add/batch",
            method = RequestMethod.POST)
    ResponseEntity<?> createEmploymentTermsBatch(@ApiParam(value = "", required = true) @RequestBody List<EmploymentTerms> employmentterms);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Edit an existing EmploymentTerms",
            notes = "Edit an existing employmentterms",
            response = EmploymentTerms.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "EmploymentTerms Details", response = EmploymentTerms.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/employmentterms/{id}",
            method = RequestMethod.PUT)
    ResponseEntity<?> editEmploymentTerms(@ApiParam(value = "", required = true) @PathVariable("id") long employmentterms_id,
                                          @ApiParam(value = "", required = true) @RequestBody EmploymentTerms employmentterms);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing EmploymentTerms",
            notes = "Delete an existing employmentterms",
            response = EmploymentTerms.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "EmploymentTerms Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/employmentterms/{id}",
            method = RequestMethod.DELETE)
    ResponseEntity<String> deleteEmploymentTerms(@ApiParam(value = "", required = true) @PathVariable("id") long employmentterms_id);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing EmploymentTerms",
            notes = "Gets an existing employmentterms",
            response = EmploymentTerms.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "EmploymentTerms Details", response = EmploymentTerms.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/employmentterms/{name}",
            method = RequestMethod.GET)
    ResponseEntity<?> getEmploymentTerms(@ApiParam(value = "", required = true) @PathVariable("name") String employmentterms);

}

