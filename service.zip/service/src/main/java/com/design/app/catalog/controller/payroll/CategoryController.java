package com.design.app.catalog.controller.payroll;


import com.design.app.catalog.api.payroll.PayrollCategoryApi;
import com.design.app.catalog.model.payroll.PayrollCategory;
import com.design.app.catalog.repository.payroll.PayrollCategoryRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class CategoryController implements PayrollCategoryApi {
    @Autowired
    PayrollCategoryRepository repository;

    @Override
    public ResponseEntity<List<PayrollCategory>> getAllPayrollCategory() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<?> createPayrollCategory(PayrollCategory payrollCategory) {
        try {
            return ResponseEntity.ok(repository.saveAndFlush(payrollCategory));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }


    @Override
    public ResponseEntity<?> editPayrollCategory(long payrollCategory_id, PayrollCategory payrollCategory) {
        try {
            PayrollCategory oldPayrollCategory = repository.findById(payrollCategory_id);
            BeanUtils.copyProperties(payrollCategory, oldPayrollCategory);
            return ResponseEntity.ok(repository.save(oldPayrollCategory));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> deletePayrollCategory(long payrollCategory_id) {
        try {
            repository.delete(repository.findById(payrollCategory_id));
            return ResponseEntity.ok("PayrollCategory removed successfully");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getPayrollCategory(String payrollCategory) {
        try {
            return ResponseEntity.ok(repository.findByCategory(payrollCategory));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }
}
