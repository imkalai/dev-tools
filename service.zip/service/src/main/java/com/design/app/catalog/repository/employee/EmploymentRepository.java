package com.design.app.catalog.repository.employee;


import com.design.app.catalog.model.designation.Designation;
import com.design.app.catalog.model.employee.Employment;
import com.design.app.catalog.model.employee.Name;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmploymentRepository extends JpaRepository<Employment, Long> {
    List<Employment> findAll();

    Employment findById(long id);

    Employment findByName(Name name);

    List<Employment> findByDesignation (Designation designation);

    List<Employment> findByDivision(String division);

    List<Employment> findByLocation(String location);

    Employment findByEmailEquals(String email);

    Employment findByEmployeeCode(String employeeCode);
}