package com.design.app.catalog.model.leave;

import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.team.Manager;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "leave")
public class Leave {
    @javax.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @ManyToOne
    @JoinColumn(name = "name_id")
    private Name name;

    @ManyToOne
    @JoinColumn(name = "manager_id")
    private Manager manager;

    private String type;
    private LocalDate fromDate;
    private String fromSession;
    private LocalDate toDate;
    private String toSession;
    private String reason;
    private double duration;
    private String status;
    private String employeeCode;

    public Leave() {
    }

    public long getId() {
        return Id;
    }

    public Name getName() {
        return name;
    }

    public void setName(Name name) {
        this.name = name;
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public LocalDate getFromDate() {
        return fromDate;
    }

    public void setFromDate(LocalDate fromDate) {
        this.fromDate = fromDate;
    }

    public String getFromSession() {
        return fromSession;
    }

    public void setFromSession(String fromSession) {
        this.fromSession = fromSession;
    }

    public LocalDate getToDate() {
        return toDate;
    }

    public void setToDate(LocalDate toDate) {
        this.toDate = toDate;
    }

    public String getToSession() {
        return toSession;
    }

    public void setToSession(String toSession) {
        this.toSession = toSession;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public double getDuration() {
        return duration;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        switch (status.toLowerCase()) {
            case "approved":
                this.status = "Approved";
                break;
            case "rejected":
                this.status = "Rejected";
                break;
            default:
                this.status = "Pending Approval";
                break;
        }
    }

    public String getEmployeeCode() {
        return employeeCode;
    }

    public void setEmployeeCode(String employeeCode) {
        this.employeeCode = employeeCode;
    }
}
