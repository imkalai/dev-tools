package com.design.app.catalog.repository.joblog;

import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.model.joblog.JobLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;

public interface JobLogRepository extends JpaRepository<JobLog, Long> {
    List<JobLog> findAll();

    JobLog findById(long id);

    List<JobLog> findByStatusEquals(String status);

    List<JobLog> findByStatusNotLike(String status);

    @Query(value = "select * from joblog j where j.name_id=?1 and date_part('year', j.date)=?2 and date_part('month', j.date)=?3 and j.status=?4", nativeQuery = true)
    List<JobLog> getJobLogByEmployeeByPeriod(long name_id, long year, long month, String status);


//@Query(value = "SELECT rating, count(1) from review r where r.product_id=?1 group by rating", nativeQuery = true)
}

