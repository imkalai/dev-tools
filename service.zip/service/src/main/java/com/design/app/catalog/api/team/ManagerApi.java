package com.design.app.catalog.api.team;

import com.design.app.catalog.model.team.Manager;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "Manager API", tags = {"Manager"}, description = "Manager API")
@RequestMapping(value = "/app/catalog")
public interface ManagerApi {

    @ApiOperation(value = "Gets all managers",
            notes = "Returns all managers from db",
            response = Manager.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of managers", response = Manager.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/manager/all",
            method = RequestMethod.GET)
    ResponseEntity<List<Manager>> getAllManager();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new Manager",
            notes = "Creates a new manager",
            response = Manager.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Manager Details", response = Manager.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/manager/add",
            method = RequestMethod.POST)
    ResponseEntity<?> createManager(@ApiParam(value = "", required = true) @RequestBody Manager manager);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of Managers",
            notes = "Creates a set of Managers",
            response = Manager.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Manager Details", response = Manager.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/manager/add/batch",
            method = RequestMethod.POST)
    ResponseEntity<?> createManagerBatch(@ApiParam(value = "", required = true) @RequestBody List<Manager> managers);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing Manager",
            notes = "Edit an existing manager",
            response = Manager.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Manager Details", response = Manager.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/manager/{id}",
            method = RequestMethod.PUT)
    ResponseEntity<?> editManager(@ApiParam(value = "", required = true) @PathVariable("id") long manager_id,
                                        @ApiParam(value = "", required = true) @RequestBody Manager manager);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing Manager",
            notes = "Delete an existing manager",
            response = Manager.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Manager Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/manager/{id}",
            method = RequestMethod.DELETE)
    ResponseEntity<String> deleteManager(@ApiParam(value = "", required = true) @PathVariable("id") long manager_id);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing Manager",
            notes = "Gets an existing manager",
            response = Manager.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Manager Details", response = Manager.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/manager/{id}",
            method = RequestMethod.GET)
    ResponseEntity<?> getManager(@ApiParam(value = "", required = true) @PathVariable("id") long manager_id);

}
