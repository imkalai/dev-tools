package com.design.app.catalog.api.designation;


import com.design.app.catalog.model.designation.Designation;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "Designation API", tags = {"Designation"}, description = "Designation API")
@RequestMapping(value = "/app/catalog")
public interface DesignationApi {

    @ApiOperation(value = "Gets all Designations",
            notes = "Returns all Designations from db",
            response = Designation.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of Categories", response = Designation.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/designation/all",
            method= RequestMethod.GET)
    ResponseEntity<List<Designation>> getAllDesignations();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new Designation",
            notes = "Creates a new Designation",
            response = Designation.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Designation Details", response = Designation.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/designation/add",
            method= RequestMethod.POST)
    ResponseEntity<Designation> createDesignation(@ApiParam(value = "", required = true) @RequestBody Designation Designation);
/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of Designations",
            notes = "Creates a set of Designations",
            response = Designation.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Designation Details", response = Designation.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/designation/add/batch",
            method= RequestMethod.POST)
    ResponseEntity<?> createDesignationBatch(@ApiParam(value = "", required = true) @RequestBody List<Designation> Designations);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing Designation",
            notes = "Edit an existing Designation",
            response = Designation.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Designation Details", response = Designation.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/designation/{id}",
            method= RequestMethod.PUT)
    ResponseEntity<Designation> editDesignation(@ApiParam(value = "", required = true) @PathVariable("id") long Designation_id,
                                                @ApiParam(value = "", required = true) @RequestBody Designation Designation);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing Designation",
            notes = "Delete an existing Designation",
            response = Designation.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Designation Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/designation/{id}",
            method= RequestMethod.DELETE)
    ResponseEntity<String> deleteDesignation(@ApiParam(value = "", required = true) @PathVariable("id") long Designation_id);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Gets an existing Designation",
            notes = "Gets an existing Designation",
            response = Designation.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Designation Details", response = Designation.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/designation/{id}",
            method= RequestMethod.GET)
    ResponseEntity<Designation> getDesignation(@ApiParam(value = "", required = true) @PathVariable("id") long Designation_id);



}
