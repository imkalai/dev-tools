package com.design.app.catalog.api.login;

import com.design.app.catalog.model.login.Credentials;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "Credentials API", tags = {"Credentials"}, description = "Credentials API")
@RequestMapping(value = "/app/catalog")
public interface CredentialsApi {

    @ApiOperation(value = "Gets all credentials",
            notes = "Returns all credentials from db",
            response = Credentials.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of credentials", response = Credentials.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/credentials/all",
            method = RequestMethod.GET)
    ResponseEntity<List<Credentials>> getAllCredentials();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new Credentials",
            notes = "Creates a new credentials",
            response = Credentials.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Credentials Details", response = Credentials.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/credentials/add",
            method = RequestMethod.POST)
    ResponseEntity<?> createCredentials(@ApiParam(value = "", required = true) @RequestBody Credentials credentials);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of Credentialss",
            notes = "Creates a set of Credentialss",
            response = Credentials.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Credentials Details", response = Credentials.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/credentials/add/batch",
            method = RequestMethod.POST)
    ResponseEntity<?> createCredentialsBatch(@ApiParam(value = "", required = true) @RequestBody List<Credentials> credentials);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing Credentials",
            notes = "Edit an existing credentials",
            response = Credentials.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Credentials Details", response = Credentials.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/credentials/{id}",
            method = RequestMethod.PUT)
    ResponseEntity<?> editCredentials(@ApiParam(value = "", required = true) @PathVariable("id") long credentials_id,
                                      @ApiParam(value = "", required = true) @RequestBody Credentials credentials);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing Credentials",
            notes = "Delete an existing credentials",
            response = Credentials.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Credentials Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/credentials/{id}",
            method = RequestMethod.DELETE)
    ResponseEntity<String> deleteCredentials(@ApiParam(value = "", required = true) @PathVariable("id") long credentials_id);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing Credentials",
            notes = "Gets an existing credentials",
            response = Credentials.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Credentials Details", response = Credentials.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/credentials/{id}",
            method = RequestMethod.GET)
    ResponseEntity<Credentials> getCredentials(@ApiParam(value = "", required = true) @PathVariable("id") long credentials_id);

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing Credentials",
            notes = "Gets an existing credentials",
            response = Credentials.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Credentials Details", response = Credentials.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value = "/credentials/verify/{username}/{password}",
            method = RequestMethod.GET)
    ResponseEntity<?> verifyCredentials(@ApiParam(value = "", required = true) @PathVariable("username") String username, @ApiParam(value = "", required = true) @PathVariable("password") String password);

}
