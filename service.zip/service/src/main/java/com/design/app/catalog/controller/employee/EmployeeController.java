package com.design.app.catalog.controller.employee;

import com.design.app.catalog.api.employee.EmployeeApi;
import com.design.app.catalog.model.account.Account;
import com.design.app.catalog.model.department.Department;
import com.design.app.catalog.model.designation.Designation;
import com.design.app.catalog.model.employee.*;
import com.design.app.catalog.repository.account.AccountRepository;
import com.design.app.catalog.repository.department.DepartmentRepository;
import com.design.app.catalog.repository.designation.DesignationRepository;
import com.design.app.catalog.repository.employee.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class EmployeeController implements EmployeeApi {

    @Autowired
    AccountsRepository accountsRepository;

    @Autowired
    AssetsRepository assetsRepository;

    @Autowired
    CertificatesRepository certificatesRepository;

    @Autowired
    EducationRepository educationRepository;

    @Autowired
    EmploymentRepository employmentRepository;

    @Autowired
    FamilyRepository familyRepository;

    @Autowired
    NameRepository nameRepository;

    @Autowired
    PersonalRepository personalRepository;

    @Autowired
    StatuatoryRepository statuatoryRepository;

    @Autowired
    DesignationRepository designationRepository;

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    DepartmentRepository departmentRepository;

    @Autowired
    EmployeeRepository repository;


    @Override
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<?> getEmployee(long employee_id) {
        try {
            Employee employee = repository.findById(employee_id);
            if (employee != null)
                return ResponseEntity.ok(employee);
            else
                return ResponseEntity.badRequest().body("Employee not exists.");

        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }

    }

    @Override
    public ResponseEntity<?> createEmployee(Employee employee) {
        try {
            if (checkIfNotExists(employee)) {
                if (saveEntities(employee))
                    return ResponseEntity.ok(repository.saveAndFlush(employee));
            }
            return ResponseEntity.badRequest().body("Bad Request. Validation Failed");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }

    }

    @Override
    public ResponseEntity<?> createEmployeeBatch(List<Employee> employees) {
        List<Employee> successEmployees = new ArrayList<>();
        List<Employee> failedEmployees = new ArrayList<>();
        try {
            for (Employee employee : employees) {
                System.out.println("Processing Employee: "+employee.getName().getEmployeeCode());
                if (checkIfNotExists(employee)) {
                    if (saveEntities(employee))
                        successEmployees.add(repository.saveAndFlush(employee));
                } else
                    failedEmployees.add(employee);

            }
            if (successEmployees.size() > 0) {
                if (failedEmployees.size() > 0) {
                    System.out.println(failedEmployees);
                }
                return ResponseEntity.ok("Success Employees:\n" + successEmployees + "\n\n" + " Failed Employees (" + failedEmployees.size() + "):\n" + failedEmployees);
            } else {
                System.out.println(failedEmployees);
                return ResponseEntity.badRequest().body("Failed to onboard some employee(s). Please check the logs");
            }
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }

    }

    @Override
    public ResponseEntity<?> editEmployee(long employee_id, Employee employee) {
        try {
            Employee oldEmployee = repository.findById(employee_id);
            if (updateEntries(oldEmployee, employee))
                return ResponseEntity.ok(repository.saveAndFlush(oldEmployee));
            return ResponseEntity.badRequest().body("Bad Request. Failed at saving entities");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    @Override
    public ResponseEntity<String> deleteEmployee(long employee_id) {
        try {
            Employee employee = repository.findById(employee_id);
            if (employee != null) {
                repository.delete(repository.findById(employee_id));
                deleteEntities(employee);
                return ResponseEntity.ok("Employee removed successfully");
            }
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
        return ResponseEntity.badRequest().body("Failed at removing employee");
    }

    @Override
    public ResponseEntity<?> getEmployeeByEmail(String email) {
        try {
            Employment employment = employmentRepository.findByEmailEquals(email);
            if (employment != null) {
                Employee employee = repository.findByEmploymentDetails(employment);
                return ResponseEntity.ok(employee);
            }
            return ResponseEntity.badRequest().body("Invalid Email.");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        }
    }

    private boolean checkIfNotExists(Employee employee) {
        Name name = nameRepository.findByEmployeeCode(employee.getName().getEmployeeCode());
//        Name name = names.size() > 0 ? names.get(0) : null;
        if (name == null) {
            name = new Name(employee.getName().getFirstName(), employee.getName().getLastName());
            name.setEmployeeCode(employee.getName().getEmployeeCode());
            employee.setName(name);
            updateNameEntity(employee, name);
            Designation designation = designationRepository.findByAlias(employee.getEmploymentDetails().getDesignation().getName());
            employee.getEmploymentDetails().setDesignation(designation);
            if (designation != null) {

                Department department = departmentRepository.findByAlias(employee.getEmploymentDetails().getDepartment().getAlias());
                employee.getEmploymentDetails().setDepartment(department);
                if (department != null)
                    return true;

//                Account account = accountRepository.findByName(employee.getEmploymentDetails().getAccount().getName());
//                employee.getEmploymentDetails().setAccount(account);
//                if (account != null) {
//                    return true;
//                } else {
//                    Department department = departmentRepository.findByName(employee.getEmploymentDetails().getDepartment().getName());
//                    employee.getEmploymentDetails().setDepartment(department);
//                    if (department != null)
//                        return true;
//                }
            }
        }
        return false;
    }

    private boolean updateNameEntity(Employee employee, Name name) {
        try {
            employee.getPersonalDetails().setName(name);
            employee.getEmploymentDetails().setName(name);
            employee.getAccountDetails().setName(name);
            employee.getAssetDetails().setName(name);
            employee.getFamilyDetails().setName(name);
            employee.getEducationDetails().setName(name);
            employee.getStatuatoryDetails().setName(name);
            employee.getCertificateDetails().setName(name);
            return true;
        } catch (Exception ex) {
            return false;
        }

    }

    private boolean saveEntities(Employee employee) {
        try {
            nameRepository.saveAndFlush(employee.getName());
            personalRepository.saveAndFlush(employee.getPersonalDetails());
            employmentRepository.saveAndFlush(employee.getEmploymentDetails());
            educationRepository.saveAndFlush(employee.getEducationDetails());
            familyRepository.saveAndFlush(employee.getFamilyDetails());
            statuatoryRepository.saveAndFlush(employee.getStatuatoryDetails());
            certificatesRepository.saveAndFlush(employee.getCertificateDetails());
            assetsRepository.saveAndFlush(employee.getAssetDetails());
            accountsRepository.saveAndFlush(employee.getAccountDetails());
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    private boolean deleteEntities(Employee employee) {
        try {
            personalRepository.delete(employee.getPersonalDetails());
            employmentRepository.delete(employee.getEmploymentDetails());
            educationRepository.delete(employee.getEducationDetails());
            familyRepository.delete(employee.getFamilyDetails());
            accountsRepository.delete(employee.getAccountDetails());
            statuatoryRepository.delete(employee.getStatuatoryDetails());
            assetsRepository.delete(employee.getAssetDetails());
            certificatesRepository.delete(employee.getCertificateDetails());
            nameRepository.delete(employee.getName());
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    private boolean updateEntries(Employee oldEmployee, Employee employee) {
        try {
            Name name = nameRepository.findById(oldEmployee.getName().getId());
            Account account = accountRepository.findByName(employee.getEmploymentDetails().getAccount().getName());
            Designation designation = designationRepository.findByName(employee.getEmploymentDetails().getDesignation().getName());

            BeanUtils.copyProperties(employee.getName(), name);
            nameRepository.saveAndFlush(name);

            Personal personal = personalRepository.findById(oldEmployee.getPersonalDetails().getId());
            BeanUtils.copyProperties(employee.getPersonalDetails(), personal);
            personal.setName(name);
            personalRepository.saveAndFlush(personal);

            Employment employment = employmentRepository.findById(oldEmployee.getEmploymentDetails().getId());
            BeanUtils.copyProperties(employee.getEmploymentDetails(), employment);
            employment.setName(name);
            employment.setAccount(account);
            employment.setDesignation(designation);
            employmentRepository.saveAndFlush(employment);

            Education education = educationRepository.findById(oldEmployee.getEducationDetails().getId());
            BeanUtils.copyProperties(employee.getEducationDetails(), education);
            education.setName(name);
            educationRepository.saveAndFlush(education);

            Family family = familyRepository.findById(oldEmployee.getFamilyDetails().getId());
            BeanUtils.copyProperties(employee.getFamilyDetails(), family);
            family.setName(name);
            familyRepository.saveAndFlush(family);

            Accounts accounts = accountsRepository.findById(oldEmployee.getAccountDetails().getId());
            BeanUtils.copyProperties(employee.getAccountDetails(), accounts);
            accounts.setName(name);
            accountsRepository.saveAndFlush(accounts);

            Statuatory stats = statuatoryRepository.findById(oldEmployee.getStatuatoryDetails().getId());
            BeanUtils.copyProperties(employee.getStatuatoryDetails(), stats);
            stats.setName(name);
            statuatoryRepository.saveAndFlush(stats);

            Assets asset = assetsRepository.findById(oldEmployee.getAssetDetails().getId());
            BeanUtils.copyProperties(employee.getAssetDetails(), asset);
            asset.setName(name);
            assetsRepository.saveAndFlush(asset);

            Certificates certificates = certificatesRepository.findById(oldEmployee.getCertificateDetails().getId());
            BeanUtils.copyProperties(employee.getCertificateDetails(), certificates);
            certificates.setName(name);
            certificatesRepository.saveAndFlush(certificates);

            return true;
        } catch (Exception ex) {
            return false;
        }
    }
}
