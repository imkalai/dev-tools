package com.design.app.catalog.repository.employee;


import com.design.app.catalog.model.employee.*;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findAll();

    Employee findById(long id);

    Employee findByName(Name name);

    Employee findByPersonalDetails(Personal personal);

    Employee findByEmploymentDetails(Employment employment);

    Employee findByAccountDetails(Accounts accounts);

    Employee findByStatuatoryDetails(Statuatory statuatory);

    Employee findByEducationDetails(Education education);

    Employee findByFamilyDetails(Family family);

    Employee findByAssetDetails(Assets assets);

    Employee findByCertificateDetails(Certificates certificates);

}