package com.design.app.catalog.api.account;


import com.design.app.catalog.model.account.Account;
import io.swagger.annotations.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "Account API", tags = {"Account"}, description = "Account API")
@RequestMapping(value = "/app/catalog")
public interface AccountApi {

    @ApiOperation(value = "Gets all accounts",
            notes = "Returns all accounts from db",
            response = Account.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "the list of accounts", response = Account.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/account/all",
            method= RequestMethod.GET)
    ResponseEntity<List<Account>> getAllAccount();

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates new Account",
            notes = "Creates a new account",
            response = Account.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Account Details", response = Account.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/account/add",
            method= RequestMethod.POST)
    ResponseEntity<?> createAccount(@ApiParam(value = "",required = true) @RequestBody Account account);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Creates a set of Accounts",
            notes = "Creates a set of Accounts",
            response = Account.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Account Details", response = Account.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/account/add/batch",
            method= RequestMethod.POST)
    ResponseEntity<?> createAccountBatch(@ApiParam(value = "", required = true) @RequestBody List<Account> accounts);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Edit an existing Account",
            notes = "Edit an existing account",
            response = Account.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Account Details", response = Account.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/account/{id}",
            method= RequestMethod.PUT)
    ResponseEntity<?> editAccount(@ApiParam(value = "",required = true) @PathVariable("id") long account_id,
                                        @ApiParam(value = "",required = true) @RequestBody Account account);

/////////////////////////////////////////////////////////////////////////////

    @ApiOperation(value = "Delete an existing Account",
            notes = "Delete an existing account",
            response = Account.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Account Deleted Successfully", response = String.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/account/{id}",
            method= RequestMethod.DELETE)
    ResponseEntity<String> deleteAccount(@ApiParam(value = "",required = true) @PathVariable("id") long account_id  );

/////////////////////////////////////////////////////////////////////////////


    @ApiOperation(value = "Gets an existing Account",
            notes = "Gets an existing account",
            response = Account.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Account Details", response = Account.class),
            @ApiResponse(code = 401, message = "Unauthorized"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found")})

    @CrossOrigin
    @RequestMapping(value="/account/{name}",
            method= RequestMethod.GET)
    ResponseEntity<?> getAccount(@ApiParam(value = "",required = true) @PathVariable("name") String account);

}
