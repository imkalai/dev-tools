package com.design.app.catalog.repository.employee;


import com.design.app.catalog.model.employee.Family;
import com.design.app.catalog.model.employee.Name;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FamilyRepository extends JpaRepository<Family, Long> {
    List<Family> findAll();

    Family findById(long id);

    Family findByName(Name name);
}