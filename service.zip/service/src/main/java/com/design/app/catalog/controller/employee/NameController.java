package com.design.app.catalog.controller.employee;


import com.design.app.catalog.api.employee.NameApi;
import com.design.app.catalog.model.employee.Name;
import com.design.app.catalog.repository.employee.NameRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class NameController implements NameApi {

    @Autowired
    NameRepository repository;


    @Override
    public ResponseEntity<List<Name>> getAllNames() {
        return ResponseEntity.ok(repository.findAll());
    }

    @Override
    public ResponseEntity<?> createName(Name name) {
        if (validateName(name) == null) {
            return ResponseEntity.ok(repository.saveAndFlush(name));
        } else
            return ResponseEntity.badRequest().body("Name already exists");
    }

    @Override
    public ResponseEntity<?> createNameBatch(List<Name> names) {
        List<Name> existingNames = new ArrayList<>();
        List<Name> newNames = new ArrayList<>();
        List<Name> savedNames = new ArrayList<>();

        for (Name name : names) {
            Name vName = validateName(name);
            if (vName != null)
                existingNames.add(name);
            else
                newNames.add(name);
        }
        if (newNames.size() > 0)
            savedNames = repository.saveAll(newNames);

        if (existingNames.size() > 0)
            return ResponseEntity.badRequest().body("Name(s) already exists: " + existingNames);
        else
            return ResponseEntity.ok(savedNames);
    }

    @Override
    public ResponseEntity<Name> editName(long name_id, Name name) {
        Name oldName = repository.findById(name_id);
        BeanUtils.copyProperties(name, oldName);
        return ResponseEntity.ok(repository.save(oldName));
    }

    @Override
    public ResponseEntity<String> deleteName(long Name_id) {
        repository.delete(repository.findById(Name_id));
        return ResponseEntity.ok("Name removed successfully");
    }

    @Override
    public ResponseEntity<List<Name>> getFilteredName(String name) {
        return ResponseEntity.ok(repository.findByFirstNameContains(name));
    }

    private Name validateName(Name name) {
        Name oldName = repository.findByEmployeeCode(name.getEmployeeCode());
        return oldName;
    }
}
