package com.design.app.catalog.repository.account;

import com.design.app.catalog.model.account.Account;
import com.design.app.catalog.model.employee.Accounts;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountRepository extends JpaRepository<Account, Long> {
    List<Account> findAll();

    Account findById(long id);

    Account findByName(String accountName);

    List<Account> findByDepartment_Name(String departmentName);


}